@extends('layouts.app')

@section('content')
<my-header1></my-header1>
<my-404></my-404>
<my-footer></my-footer>
@endsection
