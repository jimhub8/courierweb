@extends('layouts.app')

@section('content')
<my-header1></my-header1>
<my-500></my-500>
<my-footer></my-footer>
@endsection
