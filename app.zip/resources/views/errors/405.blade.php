@extends('layouts.app')

@section('content')
<my-header1></my-header1>
<my-405></my-405>
<my-footer></my-footer>
@endsection
