@extends('layouts.appb')

@section('content')
<div>
        <textarea name="content" class="form-control my-editor"></textarea>
Lorem ipsum dolor sit, amet consectetur adipisicing elit. Rerum ratione quasi cupiditate dolor, soluta modi nam eius repudiandae delectus laudantium. Ducimus, eius. Perferendis, alias? Cumque, quo. Illum odit in mollitia.
</div>
@endsection
