@extends('layouts.app')
@section('content')
<textarea class="form-control" id="summary-ckeditor" name="summary-ckeditor"></textarea>
@endsection

Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quibusdam deserunt minima eius molestiae voluptas consectetur. Nihil dolor fugit, possimus perspiciatis alias dolores numquam quae recusandae placeat doloremque odio ab repellat!