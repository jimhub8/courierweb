<template>
<div>
    <div class="translogistic-wrapper" id="general-wrapper">
        <div class="site-sub-content clearfix">
            <div class="page-content-banner" style="background-image:url('/storage/web/404.jpg'); margin-top: 160px"></div>
            <div class="page-content">
                <article class="page page404">
                    <div class="content404">
                        <h1>500</h1>
                        <h2>page</h2>
                        <p class="top-desc">sorry that <span>page does not </span>exist</p>
                        <p class="bottom-desc">Something went wrong. Go home by <a href="/">clicking here.</a></p>
                    </div>
                </article>
            </div>
        </div>
    </div>
</div>
</template>
