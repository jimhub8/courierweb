<template>
<div style="background: url('/storage/web/home2-slider1.jpg') center fixed;">
    <div class="vc_row wpb_row vc_row-fluid vc_row-o-equal-height vc_row-flex">
        <div class="bgfixed backgroundbottomright wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
            <div class="vc_column-inner vc_custom_1458848330953">
                <div class="wpb_wrapper"></div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill" style="background: #0076c0;">
            <div class="vc_column-inner vc_custom_1458509088178">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left mobile-padding-none  wow fadeIn animate-delay-0 vc_custom_1459354850277 fadeIn" style="margin-bottom: 20px;">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458508937335">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom20px big">
                                        <div class="icon-list-icon" style="border-color:#ffffff;color:#ffffff;"><i
                                            class="fa fa-bus"></i></div>
                                        <h3 style="color:#ffffff;">A shipping solution to save time and money</h3>
                                        <p style="font-size:11.5px;color:#ffffff;">Add two lines of code to your website and start delivering products to your preferred destinations. Our shipping APIs already connect with PayPal, VISA, MasterCard, M-PESA and many others.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left mobile-padding-none  wow fadeIn animate-delay-0-25 vc_custom_1459354869506  fadeIn" style="margin-bottom: 20px;">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458508943681">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom20px big">
                                        <div class="icon-list-icon" style="border-color:#ffffff;color:#ffffff;"><i
                                            class="fa fa-archive"></i></div>
                                        <h3 style="color:#ffffff;">A seamless shipping experience, on-site</h3>
                                        <p style="font-size:11.5px;color:#ffffff;">Boxleo gives you simple “Ship to” HTML buttons & a customizable JavaScript shipping pages where clients can enter their shipping addresses. Result? Customers shop, pay and get their products delivered without you ever picking phone to call a delivery agent.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left mobile-padding-none  wow fadeIn animate-delay-0-50 vc_custom_1459354874647  fadeIn" style="margin-bottom: 20px;">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458508951333">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom20px big">
                                        <div class="icon-list-icon" style="border-color:#ffffff;color:#ffffff;"><i
                                            class="fa fa-anchor"></i></div>
                                        <h3 style="color:#ffffff;">Shipping integration with any technology</h3>
                                        <p style="font-size:11.5px;color:#ffffff;">Connect with e-commerce platforms, business websites, CRMs, inventory management systems & several other solutions. Harness the power of our API and webhooks to use Boxleo data anywhere.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left mobile-padding-none  wow fadeIn animate-delay-0-75 vc_custom_1459355105558  fadeIn" style="margin-bottom: 20px;">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458508957793">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom20px big">
                                        <div class="icon-list-icon" style="border-color:#ffffff;color:#ffffff;"><i
                                            class="fa fa-arrows-alt"></i></div>
                                        <h3 style="color:#ffffff;">Manage your orders with a comprehensive dashboard</h3>
                                        <p style="font-size:11.5px;color:#ffffff;">Boxleo is more than a simple courier: enjoy a full back-office orders management dashboard to track delivered orders, orders in transit, failed deliveries, customer orders and more.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
