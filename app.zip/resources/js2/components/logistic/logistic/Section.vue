<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid container">
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029076462">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="image" style="background-image:url(/storage/web/logistic-feature-box-1.jpg);">
                        </div>
                        <div class="feature-box-content">
                            <div class="feature-box-icon"><i class="fa fa-hand-pointer-o"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms">NO SETUP FEES</h4>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">Getting started is free.
                                Our packages come with zero setup fees. All you have to do is just contact us for API integrations.
                            </p>
                            <div class="button">
                                <v-btn class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">MORE</router-link>
                                </v-btn>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029085473">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="feature-box-content bottom">
                            <div class="feature-box-icon"><i class="fa fa-truck"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms">INSTANT SETUP</h4>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">We’ve stripped away all the complexity.
                                Your store or website will be setup in minutes.
                            </p>
                            <br>
                            <div class="button">
                                <v-btn class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">MORE</router-link>
                                </v-btn>

                            </div>
                        </div>
                        <div class="image bottom" style="background-image:url(/storage/web/logistic-feature-box-2.jpg);">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029096986">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="image" style="background-image:url(/storage/web/logistic-feature-box-3.jpg);">
                        </div>
                        <div class="feature-box-content">
                            <div class="feature-box-icon"><i class="fab fa-dropbox"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms" style="font-size: 13px;">SEAMLESS SHIPPING MANAGEMENT
                            </h4>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">We’ve come in to save you from the hustle of having to contact a delivery agent whenever you have an order. </p>
                            <div class="button">
                                <v-btn class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">MORE</router-link>
                                </v-btn>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
