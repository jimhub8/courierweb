<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid container vc_custom_1463481845812 vc_row-o-content-bottom vc_row-flex">
        <div class="wow fadeInLeft wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459355126012">
                <div class="wpb_wrapper">
                    <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1463481943332">
                        <figure class="wpb_wrapper vc_figure">
                            <div class="vc_single_image-wrapper vc_box_border_grey">
                                <img width="311" height="466" src="/storage/web/logistic-layer-3.jpg" class="vc_single_image-img attachment-full" alt=""sizes="(max-width: 311px) 100vw, 311px"></div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="wow fadeIn wpb_column vc_column_container vc_col-sm-8">
            <div class="vc_column-inner vc_custom_1459355135176">
                <div class="wpb_wrapper">
                    <h3 style="font-size: 15px;color: #858585;text-align: left" class="vc_custom_heading vc_custom_1458565908042">OUR API SOLUTIONS</h3>
                    <div class="wpb_text_column wpb_content_element">
                        <div class="wpb_wrapper">
                            <p>Along our already great range of services, Boxleo Courier also offers you the opportunity to connect your systems with ours. The technical term for this is called API, meaning that you will be able to offer your customers to choose from a fantastic array of personal, pre-selected solutions to get their orders delivered how they want it. When they want it.</p>
                            <p>Using the Boxleo Courier shipment website integration API you can quickly and easily add streamlined shipment services to your website.</p>
                            <p>No more messing about carting items to a delivery depot, you can integrate your door-to-door courier services directly into your existing shopping cart web site.</p>
                            <p>There are two levels of integration and three different payment methods to make integration a breeze. With full client access to shipment information, reports and billing information it couldn't be easier.</p>
                            <h3><b>Key benefits:</b></h3>
                            <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
                                <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Lower prices</span></li>
                                <li><span style="color: #858585; font-weight: 500;">Total shipment automation</span></li>
                                <li><span style="color: #858585; font-weight: 500;">Competitive deferred Air Freight Service</span></li>
                                <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Seamless professional customer experience</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<Sectin3></Sectin3>
    </div>
</div>
</template>
<script>
import Sectin3 from './Section3';
export default {
    components: {
        Sectin3 
    }
}
</script>