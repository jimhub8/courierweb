<template>
<div>
    <div class="row">
        <div class="col-sm-12">
            <div data-v-488543a7="" class="contactPageForm">
                <div data-v-488543a7="" class="row wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <div data-v-488543a7="" class="col-sm-4 col-xs-12 formrow">
                        <div data-v-488543a7="" class="form-group">
                            <span data-v-488543a7="" class="wpcf7-form-control-wrap your-name">
                    <input data-v-488543a7="" type="text" name="your-name" value="" size="40" aria-required="true"
                        aria-invalid="false" placeholder="NAME"
                        class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required">
                </span>
                        </div>
                    </div>
                    <div data-v-488543a7="" class="col-sm-4 col-xs-12 formrow">
                        <div data-v-488543a7="" class="form-group"><span data-v-488543a7=""
                    class="wpcf7-form-control-wrap your-email"><input data-v-488543a7="" type="email" name="your-email"
                        value="" size="40" aria-required="true" aria-invalid="false" placeholder="E-MAIL"
                        class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email">
                </span>
                        </div>
                    </div>
                    <div data-v-488543a7="" class="col-sm-4 col-xs-12">
                        <div data-v-488543a7="" class="form-group"><span data-v-488543a7=""
                    class="wpcf7-form-control-wrap subject"><input data-v-488543a7="" type="text" name="subject"
                        value="" size="40" aria-required="true" aria-invalid="false" placeholder="SUBJECT"
                        class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required">
                </span>
                        </div>
                    </div>
                    <div data-v-488543a7="" class="col-sm-12 col-xs-12 wow fadeIn 25" style="visibility: visible; animation-name: fadeIn;">
                        <div data-v-488543a7="" class="form-group"><span data-v-488543a7=""
                    class="wpcf7-form-control-wrap your-message">
                    <textarea data-v-488543a7="" name="your-message" cols="40" rows="8" aria-invalid="false" placeholder="MESSAGE" class="wpcf7-form-control wpcf7-textarea" style="border: 1px solid rgb(194, 194, 194);"></textarea>
                </span>
                        </div>
                    </div>
                </div>
                <p data-v-488543a7="" id="submit"><input data-v-488543a7="" type="submit" value="SEND MESSAGE"
            class="wpcf7-form-control wpcf7-submit alternative-button wow fadeIn"
            style="color: rgb(11, 166, 221); background: transparent; border: 1px solid; visibility: visible; animation-name: fadeIn;">
                    <span data-v-488543a7="" class="ajax-loader"></span></p>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div data-v-488543a7="" class="wpb_wrapper">
            <h2 data-v-488543a7="" class="vc_custom_heading vc_custom_1458658597432" style="font-size: 15px; color: rgb(133, 133, 133); text-align: left;">INFORMATIONS</h2>
            <div data-v-488543a7="" class="contact-information themethreecolor">
                <div data-v-488543a7="" class="contact-information-row">
                    <div data-v-488543a7="" class="contact-information-icon"><i data-v-488543a7="" class="fa fa-map-marker"></i></div>
                    <div data-v-488543a7="" class="contact-information-content"><strong data-v-488543a7="">Address:</strong>Leomar Court, 2nd Floor, Suite No.8 </div>
                </div>
                <div data-v-488543a7="" class="contact-information-row">
                    <div data-v-488543a7="" class="contact-information-icon"><i data-v-488543a7="" class="fa fa-phone"></i></div>
                    <div data-v-488543a7="" class="contact-information-content"><strong data-v-488543a7="">Telephone:</strong>
                        + 254 743 332 743
                        <br data-v-488543a7=""> <span data-v-488543a7="">+ 254 743 332 754</span></div>
                </div>
                <div data-v-488543a7="" class="contact-information-row">
                    <div data-v-488543a7="" class="contact-information-icon"><i data-v-488543a7="" class="fa fa-envelope"></i></div>
                    <div data-v-488543a7="" class="contact-information-content"><strong data-v-488543a7="">E-Mail:</strong> info@boxleo.co.ke
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<style scoped>
#submit input:hover {
    color: #fff;
    background: #0ba6dd;
}
</style>
