<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid container vc_custom_1458659295687">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <h2 style="font-size: 15px;color: #858585;text-align: left" class="vc_custom_heading vc_custom_1458659310244">GOOGLE MAP</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_custom_1459345752147 vc_row-no-padding" style="position: relative; left: 0px; box-sizing: border-box; width: 1583px;">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner">
                <div class="wpb_wrapper">
                    <div class="wpb_gmaps_widget wpb_content_element vc_custom_1458659254365">
                        <div class="wpb_wrapper">
                            <div class="wpb_map_wraper">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.838308406031!2d36.8074450149599!3d-1.2699471359672663!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f173bcd630747%3A0xcdea28b05373edcb!2sLeomar+Court%2C+Apartments%2C+42+Westlands+Rd%2C+Nairobi!5e0!3m2!1sen!2ske!4v1556699735561!5m2!1sen!2ske" width="100" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vc_row-full-width vc_clearfix"></div>

</div>
</template>

<style scoped>
@media only screen and (max-width: 768px) {
    .wpb_gmaps_widget .wpb_map_wraper iframe {
    width: 100vw;
}
}
</style>
