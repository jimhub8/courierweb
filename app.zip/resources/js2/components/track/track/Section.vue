<template>
<v-layout wrap style="background: url('/storage/web/ship.jpg');background-position: center;background-attachment: fixed;align-items: center;">
    <v-flex sm6>
        <div class="vc_column-inner vc_custom_1459030179383">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element">
                    <div class="wpb_wrapper" style="margin-right: 30px;">
                        <p style="margin: 0px; text-align: right; font-size: 44px; color: #0076c0; line-height: 35px;">
                            <b style="margin-top: 15px;">Answers to most</b><br>
                             <b style="margin-top: 15px;">commonly asked questions</b> <br>
                             <b style="margin-top: 15px;">about Boxleo tracking.</b><br>
                             </p>
                    </div>
                </div>
            </div>
        </div>
    </v-flex>
    <v-flex sm6 style="background: rgb(0, 118, 192);color: #fff;padding: 10px;">
        <div class="mobile-padding-none wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
            <div class="vc_column-inner vc_custom_1459030221178">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="content-widget-title text-left">
                                        <h3 style="color:#fff;">Tracking FAQ</h3>
                                    </div>
                                    <v-divider></v-divider>
                                    <div class="wpb_text_column wpb_content_element vc_custom_1458572845492">
                                        <div class="wpb_wrapper">
                                            <p><span style="color: #ffffff; font-size: 18px;">General Tracking Questions</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-25 vc_custom_1459360349844 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458572363524">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom50px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;margin-top: 35px;">
                                            <span>1.</span></div>
                                        <h3 style="color:#ffffff;">I'm expecting a shipment, when will it arrive?</h3>
                                        <p style="color:#ffffff; font-size: 14px;">Track the status of your shipment on boxleo.co.ke using your tracking number and look for the estimated delivery date. We are unable to specify an exact delivery time. Typically, deliveries occur during normal business hours and depends on the service selected.
                                            If you do not have your tracking number, Customer service may be able to find your shipment information.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-50 vc_custom_1459360415350 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;margin-top: 35px;">
                                            <span>2.</span></div>
                                        <h3 style="color:#ffffff;">What kind of information can I get when tracking a shipment?
                                        </h3>
                                        <p style="color:#ffffff; font-size: 14px;">The tracking detail page provides summary information about your shipment, including your shipment's current status, travel history and estimated delivery date.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-75 vc_custom_1459360419402 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;margin-top: 85px;">
                                            <span>3.</span></div>
                                        <h3 style="color:#ffffff;">My package was supposed to be here, but it has not arrived. What can I do?
                                        </h3>
                                        <p style="color:#ffffff; font-size: 14px;">A good first step is to track the status of your package using your Boxleo tracking number. The tracking number enables us to provide you with your package's most up-to-date tracking information. If the tracking results do not answer your question, your next step can be to contact Boxleo for further assistance.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-1 vc_custom_1459360368453 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;margin-top: 55px;">
                                            <span>4.</span></div>
                                        <h3 style="color:#ffffff;">I tracked my shipment, and there haven't been updates on it in more than a day. What should I do?</h3>
                                        <p style="color:#ffffff; font-size: 14px;">Shipments in the FedEx system receive updates at various points between pickup and delivery. It is not unusual for a shipment to go more than 24 hours without an update while in transit. For additional tracking information, Please call Customer Service www.boxleo.co.ke/contact</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid animate anim-fadeIn animate-delay-1-25 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458573042272">
                                <div class="wpb_wrapper">
                                    <v-btn color="white" flat style="border: 1px solid;">
                                        <router-link to="/faqs" style="color: #fff;">Other Questions</router-link>
                                    </v-btn>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </v-flex>
</v-layout>
</template>
