<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1463483197386 vc_row-o-content-bottom vc_row-flex">
    <!-- <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1459359916064 anim-fadeInLeft">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="540" height="339" src="/storage/web/event-layer-3.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/event-layer-3.jpg 540w, /storage/web/event-layer-3-300x188.jpg 300w" sizes="(max-width: 540px) 100vw, 540px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div> -->
    <div class="wpb_column vc_column_container vc_col-sm-12" style="margin-bottom: 100px;">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <p class="anim-fadeIn animate-delay-0" style="margin-bottom: 10px !important;"><span style="color: #0ba6dd; font-size: 36px;"><strong>Packing Materials to Keep Your Items Safe:</strong></span></p>
                <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
                    <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Bubble cushioning</span></li>
                    <li><span style="color: #858585; font-weight: 500;">Foam wrap</span></li>
                    <li><span style="color: #858585; font-weight: 500;">Foam planks</span></li>
                </ul>

            </div>
        </div>
    </div>
</div>
</template>
