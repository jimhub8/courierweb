<template>
<div>
    <div class="translogistic-wrapper" id="general-wrapper" style="transform: none;">
        <div class="site-sub-content clearfix" style="transform: none;">
            <div class="page-content-banner" style="background-image:url(/storage/web/maritime-page-banner.jpg);"></div>
            <div class="page-title-wrapper">
                <h1 class="page-title">Land Transportation</h1>
                <p>Sed fermentum nisl vitae turpis tempus varius. Donec lobortis nisi tellus, eu maximus tellus accumsan<br>eget. In ac fermentum elit, id vulputate velit.</p>
            </div>
            <div class="col-lg-12 col-sm-12 col-xs-12 fullwidthsidebar">
                <div class="page-content">
                    <article id="post-42" class="post-42 page type-page status-publish has-post-thumbnail hentry">
                        <div class="page-content-bottom">
                            <div class="vc_row wpb_row vc_row-fluid container vc_custom_1458815063618">
                                <div class="wpb_column vc_column_container vc_col-sm-6">
                                    <div class="vc_column-inner">
                                        <div class="wpb_wrapper">
                                            <div class="wpb_text_column wpb_content_element">
                                                <div class="wpb_wrapper">
                                                    <p style="font-size: 17px;">Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quis risus ut nisi gravida volutpat. Fusce hendrerit quam eget bibendum finibus. In euismod rhoncus dapibus. Integer tincidunt vel.</p>
                                                    <p>Praesent nec condimentum neque, in dictum magna. Integer sagittis feugiat nisl vitae viverra. Nullam vitae purus blandit, consectetur quam nec, maximus magna. Vestibulum pharetra, sem in condimentum accumsan, lorem sem dictum turpis, eget condimentum felis tortor non nulla. Nulla malesuada, odio nec scelerisque imperdiet, tortor est bibendum ex.</p>
                                                    <p>Arcu vel mauris. Nunc pretium posuere tempus. Donec et odio eget erat finibus interdum. Nulla facilisi. Vestibulum porttitor dolor massa, ac sodales ligula interdum vitae. Integer tempus nisl in sem lobortis, eu posuere lorem aliquam. Integer justo orci, viverra vitae efficitur quis, volutpat vitae mi. Fusce at neque sem. Curabitur vitae sapien quis lacus.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-6">
                                    <div class="vc_column-inner">
                                        <div class="wpb_wrapper">
                                            <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1458815361624">
                                                <figure class="wpb_wrapper vc_figure">
                                                    <div class="vc_single_image-wrapper vc_box_border_grey"><img width="569" height="320" src="/storage/web/land_layer_1.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/land_layer_1.jpg 569w, /storage/web/land_layer_1-300x169.jpg 300w" sizes="(max-width: 569px) 100vw, 569px"></div>
                                                </figure>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="vc_row wpb_row vc_row-fluid container vc_custom_1459005247497">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="vc_column-inner">
                                        <div class="wpb_wrapper">
                                            <div class="wpb_text_column wpb_content_element">
                                                <div class="wpb_wrapper">
                                                    <p>Praesent nec condimentum neque, in dictum magna. Integer sagittis feugiat nisl vitae viverra. Nullam vitae purus blandit, consectetur quam nec, maximus magna. Vestibulum pharetra, sem in condimentum accumsan, lorem sem dictum turpis, eget condimentum felis tortor non nulla. Nulla malesuada, odio nec scelerisque imperdiet, tortor est bibendum ex, in mattis justo.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <Section></Section>

                            <Section1></Section1>

                            <div class="vc_row wpb_row vc_row-fluid bgfixed vc_custom_1459263937145 vc_row-has-fill">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="vc_column-inner vc_custom_1458318373653">
                                        <div class="wpb_wrapper">
                                            <div class="vc_row wpb_row vc_inner vc_row-fluid container vc_custom_1458318277502">
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458318908638">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter15981803520" data-last="256">256</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">SED FERMENTUM NISL</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458318918804">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter13664707056" data-last="154">154</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">DONEC AUCTOR NISL VEL ODIO</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458319924975">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter88902400000" data-last="5000">5000</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">PHASELLUS AC VOLUTPAT SAPIEN</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458319939317">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter63682311775" data-last="919">919</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">CRAS VULPUTATE NEQUE</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458319948547">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter2792117488" data-last="76">76</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">HAC HABITASSE PLATEA DICTUMST</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-2">
                                                    <div class="vc_column-inner vc_custom_1458319957942">
                                                        <div class="wpb_wrapper">
                                                            <div class="numbermator">
                                                                <h3 style="color:#ffffff;">
                                                                    <div class="counter scounter239699460572" data-last="4706">4706</div>
                                                                </h3>
                                                                <h4 style="color:#ffffff;">FUSCE A QUAM</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import Section from './trans/Section'
import Section1 from './trans/Section1'
export default {
    components: {
        Section, Section1
    },
    
    beforeRouteLeave(to, from, next) {
        eventBus.$emit("loaderEvent");
        next();
    },
}
</script>