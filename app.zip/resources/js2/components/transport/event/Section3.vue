<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1463483197386 vc_row-o-content-bottom vc_row-flex">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1459359916064 anim-fadeInLeft">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="540" height="339" src="/storage/web/event-layer-3.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/event-layer-3.jpg 540w, /storage/web/event-layer-3-300x188.jpg 300w" sizes="(max-width: 540px) 100vw, 540px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6" style="margin-bottom: 100px;">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
               <p class="anim-fadeIn animate-delay-0" style="margin-bottom: 34px;"><span style="color: #0ba6dd; font-size: 36px;"><strong>Out-of-Town and Exclusive Use Service</strong></span></p>
                <div class="wpb_text_column wpb_content_element">
                    <div class="wpb_wrapper">
                        <p><span style="color: #a4a4a4; font-size: 15px;">Let us deliver directly to another city or state at a competitive per km rate based on origin to destination. All deliveries outside the primary and secondary delivery areas are billed on a per loaded mile basis.</span></p>
                        <p><span style="color: #a4a4a4; font-size: 15px;">Driver safety is important to us. Orders going over 250 KM may require an 8 hour rest break for the driver, or a two man team, so one can rest while the other drives. We want to get your long distance delivery completed as soon as possible, but we will not ask our drivers to drive drowsy. Especially on long distance drives, please know the receiving locations / agents hours of operation so we do not arrive after a facility has closed.</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
