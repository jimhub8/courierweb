<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1458314002728">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1458729054844">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element vc_custom_1459359739073">
                    <div class="wpb_wrapper">
                        <p class="anim-fadeIn animate-delay-0" style="margin-bottom: 34px;"><span style="color: #0ba6dd; font-size: 36px;"><strong>On-Demand Delivery Services</strong></span></p>
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Reliable, same-day delivery helps you deliver improved service to your customers and meet specific business needs.</span></p>
                        <p>Boxleo Courier has the service to meet your needs. Around the clock, we use the latest in communications technology to dispatch and track a fleet of vehicles and bikes that pick up and deliver your shipments on time, every time. Within the greater metropolitan areas of Nairobi, Mombasa, Nakuru and Kisumu, we offer these same-day delivery services:
                        </p>
                        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
                            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Express: 1 hour or less (Delivery of time-critical shipments in the greater metropolitan areas within 60 minutes or less.)</span></li>
                            <li><span style="color: #858585; font-weight: 500;">Standard: 2 hours (Your package is delivered in 2 hours within the greater metropolitan area.)</span></li>
                            <li><span style="color: #858585; font-weight: 500;">Economy: 4 hours (Not urgent? Enjoy cost savings over our Standard service with delivery within 4 hours from the time your call or order is received.)</span></li>
                        </ul>

                    </div>
                </div>
                <div class="vc_row wpb_row vc_inner vc_row-fluid anim-fadeIn animate-delay-0-75">
                    <div class="wpb_column vc_column_container vc_col-sm-4 vc_hidden-xs">
                        <div class="vc_column-inner vc_custom_1459029189017">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;border-width:2px;"><i class="far fa-plus-square"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459028440954">SAME DAY COURIER</h2>
                            </div>
                        </div>
                    </div>
                    <div class="wpb_column vc_column_container vc_col-sm-4 vc_hidden-xs">
                        <div class="vc_column-inner vc_custom_1459029194491">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;border-width:2px;"><i class="fa fa-paperclip"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459028445198">SCHEDULED</h2>
                            </div>
                        </div>
                    </div>
                    <div class="wpb_column vc_column_container vc_col-sm-4 vc_hidden-xs">
                        <div class="vc_column-inner vc_custom_1459029198831">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;border-width:2px;"><i class="fa fa-bars"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459028449280">OVERNIGHT</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="anim-fadeInRight wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1459359755039">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_right vc_custom_1458736138807">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="592" height="396" src="/storage/web/event-layer-2.jpg" class="vc_single_image-img attachment-full" alt="" sizes="(max-width: 592px) 100vw, 592px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
