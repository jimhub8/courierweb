<template>
<div>


    <h2 class="wow fadeInDown">Air Freight Services:</h2>
    <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="400ms"><span style="color: #858585; font-weight: 500;list-style-type: none;">Next Flight Out</span></li>
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="700ms"><span style="color: #858585; font-weight: 500;">Overnight Freight Service</span></li>
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1s"><span style="color: #858585; font-weight: 500;">Competitive deferred Air Freight Service</span></li>
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.3s"><span style="color: #858585; font-weight: 500;list-style-type: none;">Time Definite Express Service</span></li>
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.6s"><span style="color: #858585; font-weight: 500;list-style-type: none;">Consolidation and Direct-to-Consignee Service</span></li>
        <li  class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.9s"><span style="color: #858585; font-weight: 500;list-style-type: none;">Door-to-Door and Airport-to-Airport Service</span></li>
    </ul>
</div>
</template>
