<template>
<div>
    <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1459359410629 anim-fadeIn animated fadeIn">
        <!-- <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1459359410629 animate anim-fadeIn animated fadeIn"> -->
        <figure class="wpb_wrapper vc_figure">
            <div class="vc_single_image-wrapper vc_box_border_grey"><img width="1170" height="518" src="/storage/web/event-layer-1.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/event-layer-1.jpg 1170w, /storage/web/event-layer-1-300x133.jpg 300w, /storage/web/event-layer-1-768x340.jpg 768w, /storage/web/event-layer-1-1024x453.jpg 1024w" sizes="(max-width: 1170px) 100vw, 1170px"></div>
        </figure>
    </div>
    <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Our air freight experts are ready to help throughout the process of your shipment, from handling the initial quote with detail and diligence to tracking the shipping details from origin through to final destination, your single point of contact will make the entire experience efficient, professional and assist you in reaching your business objectives. </span></p>
    <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">We know there are a number of air freight companies to choose from and feel our attention to detail provides the winning results that you seek backed by air freight rates that our experts will research and validate. When it comes to air cargo we hope you'll take the opportunity to experience our services. We have a team of professionals who are dedicated to provide you with a first class air freight & shipping service to all locations in Kenya.</span></p>
    <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Rugged and durable, Tomorrow's Journey is about bringing home a part of the world today.</span></p>

</div>
</template>
