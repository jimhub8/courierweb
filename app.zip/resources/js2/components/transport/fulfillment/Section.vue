<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1458815063618">
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="feature-box horizontal custom">
                    <div class="image left" style="background-image:url(/storage/web/land_layer_2.jpg);"></div>
                    <div class="feature-box-content left">
                        <div class="feature-box-icon"><i class="fas fa-shield-alt"></i></div>
                        <h4 class="text-left">THE PROBLEM</h4>
                        <p class="text-left">◊ High shipping costs/fees ◊ Time-Consuming Pick-And-Pack Process ◊ Poor Inventory Management ◊ Incorrectly Filled Order ◊ Long international shipping timeliness ◊ Trouble locating inventory ◊ Poor communication with suppliers ◊  Inability to Replace Lost or Damaged Products</p>
                        <!-- <p class="text-left">Condimentum felis tortor non nulla. Nulla malesuada, odio nec scelerisque imperdiet, tortor est bibendum ex, in mattis justo arcu vel mauris. Nunc pretium posuere tempus. Donec et odio.</p> -->
                        <v-btn color="white" flat style="border-radius: 20px; border: 1px solid;"><router-link to="/faqs" style="color: white;">MORE</router-link></v-btn>
                    </div>
                </div>
                <div class="feature-box horizontal custom">
                    <div class="feature-box-content right">
                        <div class="feature-box-icon"><i class="fa fa-road"></i></div>
                        <h4 class="text-left">The Solution</h4>
                        <p class="text-left">◊ Third party warehousing and logistics company with order fulfilment services that help customers manage their warehouse layout. ◊  Inventory control in its truest sense with an implemented sequential order-picking that is streamlined by distribution software and uses robust technology to track relevant data and makes sure that inventory is always up-to-date and well managed.</p>
                       
                        <v-btn color="white" flat style="border-radius: 20px; border: 1px solid;"><router-link to="/faqs" style="color: white;">MORE</router-link></v-btn>
                    </div>
                    <div class="image right" style="background-image:url(/storage/web/land_layer_3.jpg);"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
