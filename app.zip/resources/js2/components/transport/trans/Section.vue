<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1458815063618">
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="feature-box horizontal custom">
                    <div class="image left" style="background-image:url(/storage/web/land_layer_2.jpg);"></div>
                    <div class="feature-box-content left">
                        <div class="feature-box-icon"><i class="fas fa-shield-alt"></i></div>
                        <h4 class="text-left">SECURE TRANSPORTATION</h4>
                        <p class="text-left">Praesent nec condimentum neque, in dictum magna. Integer sagittis feugiat nisl vitae viverra. Nullam vitae purus blandit, consectetur quam nec, maximus magna. Vestibulum pharetra, sem in condimentum accumsan, lorem sem dictum turpis, eget.</p>
                        <p class="text-left">Condimentum felis tortor non nulla. Nulla malesuada, odio nec scelerisque imperdiet, tortor est bibendum ex, in mattis justo arcu vel mauris. Nunc pretium posuere tempus. Donec et odio.</p>
                        <div class="button"><a href="http://demo.gloriathemes.com/wp/translogistic/cargo-tracking/" title="MORE">MORE</a></div>
                    </div>
                </div>
                <div class="feature-box horizontal custom">
                    <div class="feature-box-content right">
                        <div class="feature-box-icon"><i class="fa fa-road"></i></div>
                        <h4 class="text-left">FAST AND RISK-FREE</h4>
                        <p class="text-left">Praesent nec condimentum neque, in dictum magna. Integer sagittis feugiat nisl vitae viverra. Nullam vitae purus blandit, consectetur quam nec, maximus magna. Vestibulum pharetra, sem in condimentum accumsan, lorem sem dictum turpis, eget.</p>
                        <p class="text-left">Condimentum felis tortor non nulla. Nulla malesuada, odio nec scelerisque imperdiet, tortor est bibendum ex, in mattis justo arcu vel mauris. Nunc pretium posuere tempus. Donec et odio.</p>
                        <div class="button">
                            <router-link to="/faqs">MORE</router-link>
                        </div>
                    </div>
                    <div class="image right" style="background-image:url(/storage/web/land_layer_3.jpg);"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
