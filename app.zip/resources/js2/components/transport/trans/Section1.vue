<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1463482004818 vc_row-o-content-bottom vc_row-flex">
    <div class="wpb_column vc_column_container vc_col-sm-8">
        <div class="vc_column-inner vc_custom_1458316101338">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element vc_custom_1459356516994 animate anim-fadeIn animate-delay-0 animated fadeIn">
                    <div class="wpb_wrapper">
                        <p style="margin-bottom: 33px;"><span style="color: #0ba6dd; font-size: 36px;"><strong>Cum sociis natoque penatibus et magnis dis parturient montes.</strong></span></p>
                        <p style="color: #a4a4a4; font-size: 15px;">Nascetur ridiculus mus. Donec quis risus ut nisi gravida volutpat. Fusce hendrerit quam eget bibendum finibus In euismod rhoncus dapibus. Integer tincidunt vel neque vel rhoncus. Quisque fermentum, sapien non porttitor sodales, neque velit eleifend augue, vitae aliquam nibh velit id nisi. In euismod.</p>
                        <p style="color: #a4a4a4; font-size: 15px;">Rhoncus dapibus. Integer tincidunt vel neque vel rhoncus. Quisque fermentum, sapien non porttitor sodales, neque velit eleifend augue, vitae aliquam nibh velit id nisi. Vestibulum non lobortis sapien. Aenean rhoncus porta vehicula.</p>
                    </div>
                </div>
                <div class="vc_row wpb_row vc_inner vc_row-fluid">
                    <div class="animate anim-fadeIn animate-delay-0-25 wpb_column vc_column_container vc_col-sm-3 animated fadeIn">
                        <div class="vc_column-inner vc_custom_1459356527719">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="far fa-plus-square"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459006214127">ORDER</h2>
                            </div>
                        </div>
                    </div>
                    <div class="animate anim-fadeIn animate-delay-0-50 wpb_column vc_column_container vc_col-sm-3 animated fadeIn">
                        <div class="vc_column-inner vc_custom_1459356533451">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fa fa-paperclip"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459006222180">PICK</h2>
                            </div>
                        </div>
                    </div>
                    <div class="animate anim-fadeIn animate-delay-0-75 wpb_column vc_column_container vc_col-sm-3 animated fadeIn">
                        <div class="vc_column-inner vc_custom_1459356537906">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fa fa-bars"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459006227460">PACK</h2>
                            </div>
                        </div>
                    </div>
                    <div class="animate anim-fadeIn animate-delay-1 wpb_column vc_column_container vc_col-sm-3 animated fadeIn">
                        <div class="vc_column-inner vc_custom_1459356542516">
                            <div class="wpb_wrapper">
                                <div class="icon-list center-block big">
                                    <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fa fa-object-ungroup"></i></div>
                                </div>
                                <h2 style="font-size: 13px;color: #a4a4a4;text-align: center" class="vc_custom_heading vc_custom_1459006233664">SHIP</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="animate anim-fadeInRight wpb_column vc_column_container vc_col-sm-4 animated fadeInRight">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1459262967873">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="416" height="439" src="/storage/web/home3-layer.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/home3-layer.jpg 416w, /storage/web/home3-layer-284x300.jpg 284w" sizes="(max-width: 416px) 100vw, 416px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
