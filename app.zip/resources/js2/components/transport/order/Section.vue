<template>
<div>
    <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1459359410629 anim-fadeIn animated fadeIn">
        <!-- <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1459359410629 animate anim-fadeIn animated fadeIn"> -->
        <figure class="wpb_wrapper vc_figure">
            <div class="vc_single_image-wrapper vc_box_border_grey"><img width="1170" height="518" src="/storage/web/event-layer-1.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/event-layer-1.jpg 1170w, /storage/web/event-layer-1-300x133.jpg 300w, /storage/web/event-layer-1-768x340.jpg 768w, /storage/web/event-layer-1-1024x453.jpg 1024w" sizes="(max-width: 1170px) 100vw, 1170px"></div>
        </figure>
    </div>
    <h2>On-site Packing:</h2>
    <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Whether you have an urgent, temporary or long term storage need, our warehousing team is equipped to create an individual plan for you. We offer customized solutions to each client including Last Mile deliveries for residential and commercial customers, product fulfillment services, cross dock logistics and much more. From basic storage needs to intricate warehousing and daily route deliveries, Boxleo Courier & Fulfillment Services will be your trusted partner. </span></p>
</div>
</template>
