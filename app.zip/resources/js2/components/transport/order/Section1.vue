<template>
<div>

    <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">With our wide range of pick-up and drop-off capabilities (bikes, cars, pick-up trucks, standard vans, refrigerated vans, standard straight trucks, refrigerated straight trucks and flat beds), our team will handle your warehousing needs from start to finish. </span></p>

    <h2>Why choose us?</h2>
    <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
        <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Safe, secure warehouse</span></li>
        <li><span style="color: #858585; font-weight: 500;">24/7 access to your products</span></li>
        <li><span style="color: #858585; font-weight: 500;">Logistics tailored to your needs (final mile, product fulfillment)</span></li>
        <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Qualified and trained warehousing staff including forklift operators </span></li>
        <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Delivery of pallets weighing up to 1500 pounds each</span></li>
    </ul>
    <p>We specialize in properly packing fragile and high-value items like artwork or electronics, and can package large or odd-shaped items such as golf clubs or sporting equipment. Save time and visit our offices for help from the packing experts.</p>
</div>
</template>
