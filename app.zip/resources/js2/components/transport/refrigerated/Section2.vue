<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1458314002728">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1458729054844">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element vc_custom_1459359739073">
                    <div class="wpb_wrapper">
                        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 15px;">
                            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Retention and suspension inserts </span></li>
                            <li><span style="color: #858585; font-weight: 500;">Innovative design  </span></li>
                            <li><span style="color: #858585; font-weight: 500;">Great for valuable electronics</span></li>
                            <li><span style="color: #858585; font-weight: 500;">Eliminates bulky packing materials</span></li>
                            <li><span style="color: #858585; font-weight: 500;">Fully recyclable</span></li>]
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="anim-fadeInRight wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1459359755039">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_right vc_custom_1458736138807">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="592" height="396" src="/storage/web/event-layer-2.jpg" class="vc_single_image-img attachment-full" alt="" sizes="(max-width: 592px) 100vw, 592px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
