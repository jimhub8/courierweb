<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1458314002728">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1458729054844">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element vc_custom_1459359739073">
                    <div class="wpb_wrapper">
                        <p class="anim-fadeIn animate-delay-0" style="margin-bottom: 34px;"><span style="color: #0ba6dd; font-size: 36px;"><strong>Refrigerated Transport:</strong></span></p>
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">We specialize in same day and next day refrigerated transport services – both chilled and frozen. We can make straightforward point-to-point and multi-drop deliveries. Just give us the details and leave the rest to us. Our couriers are friendly, prompt and professional.</span></p>
                        
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Our refrigerated couriers are ready for dispatch 24/7. The Boxleo Courier & Fulfillment Services fleet are all 3.5t dual temperature vans which are capable of 3 pallets and 1000kgs. All our refrigerated vehicles are fully equipped with tracking and temperature monitoring systems.</span></p>
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">We transport everything from boxes to pallets – just try us for all your refrigerated transport needs.</span></p>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="anim-fadeInRight wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1459359755039">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_right vc_custom_1458736138807">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="592" height="396" src="/storage/web/event-layer-2.jpg" class="vc_single_image-img attachment-full" alt="" sizes="(max-width: 592px) 100vw, 592px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
