<template>
<div class="vc_row wpb_row vc_row-fluid container vc_custom_1463483197386 vc_row-o-content-bottom vc_row-flex">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1459359916064 anim-fadeInLeft">
                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper vc_box_border_grey"><img width="540" height="339" src="/storage/web/event-layer-3.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/event-layer-3.jpg 540w, /storage/web/event-layer-3-300x188.jpg 300w" sizes="(max-width: 540px) 100vw, 540px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6" style="margin-bottom: 100px;">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
               <p class="anim-fadeIn animate-delay-0" style="margin-bottom: 34px;"><span style="color: #0ba6dd; font-size: 36px;"><strong>Refrigerated Courier:</strong></span></p>
                <div class="wpb_text_column wpb_content_element">
                    <div class="wpb_wrapper">
                        
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">We supply express refrigerated courier services to some of the most prestigious names in the food industry – from fast food giants to artisan delicatessens and everything in between.</span></p>
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Our experienced refrigerated couriers will deliver your goods direct to your desk, home, fridge or freezer, and take away any unwanted packaging or waste as they leave.</span></p>
                        <p class="anim-fadeIn animate-delay-0-25" style="color: #808080;"><span style="color: #a4a4a4; font-size: 15px;">Premium service comes as standard at Boxleo Courier & Fulfillment Services – we really are your number one refrigerated courier for transporting chilled or frozen food and pharmaceutical supplies. Need it the same day? Just let us know. We can make straightforward point-to-point and multi-drop deliveries. Give us the details and leave the rest to us – let our refrigerated couriers take care of everything else. Call us now on <br><b style="color: #000;font-size: 16px;">+ 254 743 332 743</b></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
