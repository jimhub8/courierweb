<template>
    <div>
        <article id="post-1185" class="post-1185 post type-post status-publish format-standard has-post-thumbnail hentry category-transport tag-advance tag-city tag-clean tag-life tag-logistic tag-new tag-service">
                                <div class="post-wrapper">
                                    <div class="post-header">
                                        <h2><a href="#" title="DoT Approves Plan For Possible Air Cargo Service To Cuba">DoT Approves Plan For Possible Air Cargo Service To Cuba</a></h2>
                                        <div class="category">
                                            <ul class="post-categories">
                                                <li><a href="http://demo.gloriathemes.com/wp/translogistic/category/transport/" rel="category tag">Transport</a></li>
                                            </ul>
                                        </div>
                                        <ul class="post-information">
                                            <li class="author"><a href="#" title="Posts by John Doe" rel="author">John Doe</a></li>
                                            <li class="date">March 27, 2016</li>
                                            <li class="comment"><a href="##comments" title="DoT Approves Plan For Possible Air Cargo Service To Cuba">0 Comment</a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content">
                                        <div class="post-image"> <a href="#" title="DoT Approves Plan For Possible Air Cargo Service To Cuba"> <img width="800" height="535" src="/storage/web/6-1-800x535.jpg" class="attachment-translogistic-blog-post-image size-translogistic-blog-post-image wp-post-image" alt=""> </a></div>
                                        <div class="post-excerpt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec metus vehicula gravida. Nullam libero ante, maximus id maximus quis, ultricies ut nisl.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec.</p>
                                        </div>
                                    </div>
                                    <div class="post-bottom"> <a href="#" title="DoT Approves Plan For Possible Air Cargo Service To Cuba" class="more">More</a>
                                        <div class="post-share">
                                            <ul>
                                                <li><a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=#&amp;t=DoT Approves Plan For Possible Air Cargo Service To Cuba" title="Share toFacebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                                <li><a class="share-twitter" href="https://twitter.com/intent/tweet?url=#&amp;text=DoT Approves Plan For Possible Air Cargo Service To Cuba" title="Share toTwitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                                <li><a class="share-googleplus" href="https://plus.google.com/share?url=#" title="Share toGoogle+" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                                <li><a class="share-linkedin" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=#&amp;title=DoT Approves Plan For Possible Air Cargo Service To Cuba" title="Share toLinkedin" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article id="post-1181" class="post-1181 post type-post status-publish format-standard has-post-thumbnail hentry category-logistic tag-advance tag-service tag-ship tag-transport tag-trend tag-truck">
                                <div class="post-wrapper">
                                    <div class="post-header">
                                        <h2><a href="#" title="Megadeals Pace Growth In 2015 Transportation &amp; Logistics">Megadeals Pace Growth In 2015 Transportation &amp; Logistics</a></h2>
                                        <div class="category">
                                            <ul class="post-categories">
                                                <li><a href="#" rel="category tag">Logistic</a></li>
                                            </ul>
                                        </div>
                                        <ul class="post-information">
                                            <li class="author"><a href="#" title="Posts by John Doe" rel="author">John Doe</a></li>
                                            <li class="date">March 27, 2016</li>
                                            <li class="comment"><a href="##comments" title="Megadeals Pace Growth In 2015 Transportation &amp; Logistics">0 Comment</a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content">
                                        <div class="post-image"> <a href="#" title="Megadeals Pace Growth In 2015 Transportation &amp; Logistics"> <img width="800" height="535" src="/storage/web/5-1-800x535.jpg" class="attachment-translogistic-blog-post-image size-translogistic-blog-post-image wp-post-image" alt=""> </a></div>
                                        <div class="post-excerpt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec metus vehicula gravida. Nullam libero ante, maximus id maximus quis, ultricies ut nisl.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec.</p>
                                        </div>
                                    </div>
                                    <div class="post-bottom"> <a href="#" title="Megadeals Pace Growth In 2015 Transportation &amp; Logistics" class="more">More</a>
                                        <div class="post-share">
                                            <ul>
                                                <li><a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=#&amp;t=Megadeals Pace Growth In 2015 Transportation &amp; Logistics" title="Share toFacebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                                <li><a class="share-twitter" href="https://twitter.com/intent/tweet?url=#&amp;text=Megadeals Pace Growth In 2015 Transportation &amp; Logistics" title="Share toTwitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                                <li><a class="share-googleplus" href="https://plus.google.com/share?url=#" title="Share toGoogle+" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                                <li><a class="share-linkedin" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=#&amp;title=Megadeals Pace Growth In 2015 Transportation &amp; Logistics" title="Share toLinkedin" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <article id="post-1167" class="post-1167 post type-post status-publish format-standard has-post-thumbnail hentry category-transport tag-advance tag-blog tag-business tag-cargo tag-carriage tag-cars">
                                <div class="post-wrapper">
                                    <div class="post-header">
                                        <h2><a href="http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/" title="Retail Sales Start The Year With Growth">Retail Sales Start The Year With Growth</a></h2>
                                        <div class="category">
                                            <ul class="post-categories">
                                                <li><a href="http://demo.gloriathemes.com/wp/translogistic/category/transport/" rel="category tag">Transport</a></li>
                                            </ul>
                                        </div>
                                        <ul class="post-information">
                                            <li class="author"><a href="#" title="Posts by John Doe" rel="author">John Doe</a></li>
                                            <li class="date">March 27, 2016</li>
                                            <li class="comment"><a href="http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/#comments" title="Retail Sales Start The Year With Growth">1 Comment</a></li>
                                        </ul>
                                    </div>
                                    <div class="post-content">
                                        <div class="post-image"> <a href="http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/" title="Retail Sales Start The Year With Growth"> <img width="800" height="535" src="/storage/web/4-800x535.jpg" class="attachment-translogistic-blog-post-image size-translogistic-blog-post-image wp-post-image" alt=""> </a></div>
                                        <div class="post-excerpt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec metus vehicula gravida. Nullam libero ante, maximus id maximus quis, ultricies ut nisl.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tempus odio ut orci egestas, ac pharetra lacus imperdiet. Vestibulum egestas nisi fringilla pulvinar blandit. In hendrerit nec.</p>
                                        </div>
                                    </div>
                                    <div class="post-bottom"> <a href="http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/" title="Retail Sales Start The Year With Growth" class="more">More</a>
                                        <div class="post-share">
                                            <ul>
                                                <li><a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/&amp;t=Retail Sales Start The Year With Growth" title="Share toFacebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                                <li><a class="share-twitter" href="https://twitter.com/intent/tweet?url=http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/&amp;text=Retail Sales Start The Year With Growth" title="Share toTwitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                                <li><a class="share-googleplus" href="https://plus.google.com/share?url=http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/" title="Share toGoogle+" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                                <li><a class="share-linkedin" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=http://demo.gloriathemes.com/wp/translogistic/retail-sales-start-the-year-with-growth/&amp;title=Retail Sales Start The Year With Growth" title="Share toLinkedin" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </article>
    </div>
</template>