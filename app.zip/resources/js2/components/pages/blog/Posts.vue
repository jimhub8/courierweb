<template>
<div>
    <div id="tag_cloud-2" class="general-sidebar-wrap widget-box widget_tag_cloud">
        <div class="widget-title">
            <h4>Tags</h4>
        </div>
        <div class="tagcloud">

            <a href="#" class="tag-cloud-link tag-link-18 tag-link-position-1" style="font-size: 22pt;" aria-label="Advance (5 items)">
                Advance
            </a>

            <a href="#" class="tag-cloud-link tag-link-21 tag-link-position-2" style="font-size: 16.75pt;" aria-label="Blog (3 items)">
                Blog
            </a>

            <a href="#" class="tag-cloud-link tag-link-12 tag-link-position-3" style="font-size: 16.75pt;" aria-label="Business (3 items)">
                Business
            </a>

            <a href="#" class="tag-cloud-link tag-link-6 tag-link-position-4" style="font-size: 16.75pt;" aria-label="Cargo (3 items)">
                Cargo
            </a>

            <a href="#" class="tag-cloud-link tag-link-16 tag-link-position-5" style="font-size: 16.75pt;" aria-label="Carriage (3 items)">
                Carriage
            </a>

            <a href="#" class="tag-cloud-link tag-link-5 tag-link-position-6" style="font-size: 16.75pt;" aria-label="Cars (3 items)">
                Cars
            </a>
            <a href="#" class="tag-cloud-link tag-link-17 tag-link-position-7" style="font-size: 8pt;" aria-label="City (1 item)">
            City
        </a>
            <a href="#" class="tag-cloud-link tag-link-20 tag-link-position-8" style="font-size: 8pt;" aria-label="Clean (1 item)">
            Clean
        </a>
            <a href="#" class="tag-cloud-link tag-link-9 tag-link-position-9" style="font-size: 8pt;" aria-label="Life (1 item)">
            Life
        </a>
            <a href="#" class="tag-cloud-link tag-link-13 tag-link-position-10" style="font-size: 8pt;" aria-label="Logistic (1 item)">
            Logistic
        </a>
            <a href="#" class="tag-cloud-link tag-link-11 tag-link-position-11" style="font-size: 8pt;" aria-label="New (1 item)">
            New
        </a>
            <a href="#" class="tag-cloud-link tag-link-15 tag-link-position-12" style="font-size: 13.25pt;" aria-label="Service (2 items)">
            Service
        </a>
            <a href="#" class="tag-cloud-link tag-link-7 tag-link-position-13" style="font-size: 8pt;" aria-label="Ship (1 item)">
            Ship
        </a>
            <a href="#" class="tag-cloud-link tag-link-8 tag-link-position-14" style="font-size: 8pt;" aria-label="Transport (1 item)">
            Transport
        </a>
            <a href="#" class="tag-cloud-link tag-link-19 tag-link-position-15" style="font-size: 8pt;" aria-label="Trend (1 item)">
            Trend
        </a>
            <a href="#" class="tag-cloud-link tag-link-14 tag-link-position-16" style="font-size: 8pt;" aria-label="Truck (1 item)">
            Truck
            </a>
        </div>
    </div>
<!-- 
    <div id="facebook_page_plugin_widget-2" class="general-sidebar-wrap widget-box widget_facebook_page_plugin_widget">
        <div class="widget-title">
            <h4>Facebook</h4>
        </div>
        <div class="cameronjonesweb_facebook_page_plugin" data-version="1.6.3" data-implementation="widget" id="qpZRPtWQKFmWbtC">
            <div id="fb-root" class=" fb_reset">
                <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
                    <div><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="https://staticxx.facebook.com/connect/xd_arbiter/r/d_vbiawPdxB.js?version=44#channel=f278d4777ac2d8&amp;origin=http%3A%2F%2Fdemo.gloriathemes.com" style="border: none;"></iframe></div>
                    <div></div>
                </div>
            </div>
            <div class="fb-page fb_iframe_widget" data-href="https://facebook.com/gloriathemes/" data-width="360" data-max-width="360" data-height="215" data-hide-cover="false" data-show-facepile="true" data-hide-cta="false" data-small-header="false" data-adapt-container-width="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=846690882110183&amp;container_width=360&amp;height=215&amp;hide_cover=false&amp;hide_cta=false&amp;href=https%3A%2F%2Ffacebook.com%2Fgloriathemes%2F&amp;locale=en_US&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;width=360"><span style="vertical-align: top; width: 0px; height: 0px; overflow: hidden;"><iframe name="f8150a556f3db4" width="360px" height="215px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" title="fb:page Facebook Social Plugin" src="https://www.facebook.com/v2.12/plugins/page.php?adapt_container_width=true&amp;app_id=846690882110183&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2Fd_vbiawPdxB.js%3Fversion%3D44%23cb%3Df15f3a4607f73c%26domain%3Ddemo.gloriathemes.com%26origin%3Dhttp%253A%252F%252Fdemo.gloriathemes.com%252Ff278d4777ac2d8%26relation%3Dparent.parent&amp;container_width=360&amp;height=215&amp;hide_cover=false&amp;hide_cta=false&amp;href=https%3A%2F%2Ffacebook.com%2Fgloriathemes%2F&amp;locale=en_US&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;width=360" style="border: none; visibility: visible; width: 0px; height: 0px;"></iframe></span></div>
        </div>
    </div>

    <div id="tp_widget_recent_tweets-2" class="general-sidebar-wrap widget-box widget_tp_widget_recent_tweets">
        <div class="widget-title">
            <h4>Twitter</h4>
        </div>
        <div class="tp_recent_tweets">
            <ul>
                <li><span>Arven WordPress photography theme is released! 
                    <a href="https://t.co/QdUfG4q92D" target="_blank">https://t.co/QdUfG4q92D</a> 
                <a href="https://t.co/UTLeDMxsei" target="_blank">https://t.co/UTLeDMxsei</a></span><a class="twitter_time" target="_blank" href="http://twitter.com/GloriaThemes/statuses/1119298404784406533">6 days ago</a></li>
                <li><span>Luxe is a 
                    <a href="https://twitter.com/search?q=WordPress" title="Search #WordPress" target="_blank">#WordPress</a> theme for architecture companies, professional architect, landscape designer, interior designe… 
                <a href="https://t.co/RCJJ2i6l39" target="_blank">https://t.co/RCJJ2i6l39</a></span><a class="twitter_time" target="_blank" href="http://twitter.com/GloriaThemes/statuses/1115573121782898689">16 days ago</a></li>
                <li><span>
                    <a href="http://twitter.com/CHERRYANTY" title="Follow CHERRYANTY" target="_blank">@CHERRYANTY</a> Hi, you can send an email from this contact form: 
                <a href="https://t.co/SHvbN5F9eO" target="_blank">https://t.co/SHvbN5F9eO</a></span><a class="twitter_time" target="_blank" href="http://twitter.com/GloriaThemes/statuses/1002543514985680896">328 days ago</a></li>
                <li><span>Our new logo is published, design by 
                    <a href="http://twitter.com/ozgu_ldn" title="Follow ozgu_ldn" target="_blank">@ozgu_ldn</a>. 
                <a href="https://t.co/Qzc0kB9hWq" target="_blank">https://t.co/Qzc0kB9hWq</a></span><a class="twitter_time" target="_blank" href="http://twitter.com/GloriaThemes/statuses/1001857270806958081">330 days ago</a></li>
            </ul>
        </div>
    </div> -->
</div>
</template>
