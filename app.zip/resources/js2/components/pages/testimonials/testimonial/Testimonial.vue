<template>
<div>
    <h2 style="font-size: 18px;color: #929191;text-align: center" class="vc_custom_heading vc_custom_1459085292914">WHAT PEOPLE ARE SAYING ABOUT US</h2>
    <h3 class="text-center" style="font-size: 17px;">Don't just take it from us, let our customers do the talking!</h3>
    <div class="testimonial-block-widget">
        <div class="owl-carousel-testimonial-block-26989330 owl-theme owl-carousel owl-loaded">
            <div class="owl-stage-outer">
                <div class="owl-stage" style="transform: translate3d(-3705px, 0px, 0px); transition: all 0.25s ease 0s; width: 7410px;">
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item active" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Boxleo Courier & Fulfillment Services provides
                                            us with a quality express courier services, with
                                            products reaching our customers in plenty of
                                            time, while offering great value for money. I would
                                            recommend them to anyone.”</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">Lilly Macharia, </span><span class="company">Zuri Kids</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Boxleo Courier & Fulfillment
                                            Services has helped us save time
                                            during key decision-making
                                            processes and implement an
                                            efficient sample delivery service to
                                            all our customers.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">Oliver Wekesa, </span><span class="company">Oloo Collection</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Boxleo Courier & Fulfillment
                                            Services has helped us save time
                                            during key decision-making
                                            processes and implement an
                                            efficient sample delivery service to
                                            all our customers</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">Jack Mose, </span><span class="company">Laila’s Fine Food</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>The service provided by Boxleo Courier & Fulfillment
                                            Services has been reliable and they feel like part
                                            of our team, as they understand our needs and
                                            requirements. We have our own dedicated account
                                            manager who ensures everything is completed. This
                                            has saved both time and reduced overall costs in
                                            comparison to other courier services</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">Elizabeth Oscar, </span><span class="company">BriLiz Medics</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Boxleo is a professional, friendly and reliable company. Whether it is getting urgent medical equipments out to waiting hospital or cost effective overnight product shipment they make it simple. I woudn't use any one else.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:rgb(0, 118, 192);">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
