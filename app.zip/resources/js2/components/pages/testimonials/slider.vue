<template>
<div>

    <div class="testimonial-block-widget">
        <div class="owl-carousel-testimonial-block-75043751 owl-theme owl-carousel owl-loaded">
            <div class="owl-stage-outer">
                <div class="owl-stage" style="transform: translate3d(-2470px, 0px, 0px); transition: all 0s ease 0s; width: 7410px;">
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item active" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75 animated fadeIn">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="owl-item cloned" style="width: 1170px; margin-right: 65px;">
                        <div class="item">
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-25">
                                    <div class="testimonial-block-item-content">
                                        <p>Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in. Nulla sed tristique nulla. Integer eu elit sit amet nunc tristique tempus. Donec sollicitudin arcu eu nisl auctor efficitur.Donec sit amet tellus iaculis, tempus augue sit amet, tempor velit. Praesent euismod nunc magna, et imperdiet neque placerat in.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                            <div class="testimonial-block-widget-content-area-columns">
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-50">
                                    <div class="testimonial-block-item-content">
                                        <p>Fusce sit amet dui vel justo ullamcorper imperdiet a non risus. In ultrices sagittis massa nec suscipit. Quisque malesuada, dui eu pellentesque.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                                <div class="testimonial-block-widget-content-area animate anim-fadeIn animate-delay-0-75">
                                    <div class="testimonial-block-item-content">
                                        <p>Ut vulputate nunc id ante congue bibendum. Nunc sit amet libero augue. Ut at nisi quis justo dapibus interdum. Duis sodales dui tempor nibh convallis, in consequat enim mattis. Donec sit amet tellus iaculis, tempus augue sit.</p>
                                    </div>
                                    <div class="testimonial-block-item-name"><span class="name" style="color:#0cdf82;">John Doe, </span><span class="company">Businessman</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="owl-controls">
                <div class="owl-nav">
                    <div class="owl-prev" style="display: none;">prev</div>
                    <div class="owl-next" style="display: none;">next</div>
                </div>
                <div class="owl-dots" style="">
                    <div class="owl-dot active"><span></span></div>
                    <div class="owl-dot"><span></span></div>
                </div>
            </div> -->
        </div>
    </div>

</div>
</template>
