<template>
<div>

    <div class="vc_row wpb_row vc_row-fluid container vc_custom_1463483469074 vc_row-o-content-bottom vc_row-flex">
        <div class="animate anim-fadeInLeft animate-delay-0 wpb_column vc_column_container vc_col-sm-4 animated fadeInLeft">
            <div class="vc_column-inner vc_custom_1459361676172">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458302766138">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fa fa-bus"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;">Zuri Kids</h3>
                                        <p style="font-size:14.5px;color:#858585;">Boxleo Courier & Fulfillment Services provides
                                            us with a quality express courier services, with
                                            products reaching our customers in plenty of
                                            time, while offering great value for money. I would
                                            recommend them to anyone.” Lilly Macharia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fas fa-shield-alt"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;">Oloo Collection</h3>
                                        <p style="font-size:14.5px;color:#858585;">“Boxleo Courier & Fulfillment
                                            Services has helped us save time
                                            during key decision-making
                                            processes and implement an
                                            efficient sample delivery service to
                                            all our customers.” Oliver Wekesa.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="animate anim-fadeInDown animate-delay-0-25 wpb_column vc_column_container vc_col-sm-4 animated fadeInDown">
            <div class="vc_column-inner">
                <div class="wpb_wrapper">
                    <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1458302608392">
                        <figure class="wpb_wrapper vc_figure">
                            <div class="vc_single_image-wrapper vc_box_border_grey"><img width="376" height="383" src="/storage/web/home3-services.jpg" class="vc_single_image-img attachment-full" alt="" srcset="/storage/web/home3-services.jpg 376w, /storage/web/home3-services-295x300.jpg 295w" sizes="(max-width: 376px) 100vw, 376px"></div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="animate anim-fadeInRight animate-delay-0-50 wpb_column vc_column_container vc_col-sm-4 animated fadeInRight">
            <div class="vc_column-inner vc_custom_1459361688139">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458302766138">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fas fa-external-link-square-alt"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;">Laila’s Fine Food</h3>
                                        <p style="font-size:14.5px;color:#858585;">The service provided by Boxleo Courier & Fulfillment
                                            Services has been reliable and they feel like part
                                            of our team, as they understand our needs and
                                            requirements. We have our own dedicated account
                                            manager who ensures everything is completed. This
                                            has saved both time and reduced overall costs in
                                            comparison to other courier services.” Jack Mose.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i class="fa fa-cube"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;">BriLiz Medics</h3>
                                        <p style="font-size:14.5px;color:#858585;">
                                            Boxleo is a professional, friendly and reliable company. Whether it is getting urgent medical equipments out to waiting hospital or cost effective overnight product shipment they make it simple. I woudn't use any one else.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
