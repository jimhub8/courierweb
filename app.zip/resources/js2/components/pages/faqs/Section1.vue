<template>
<div>
    <div class="vc_tta-container" data-vc-action="collapse">
        <div class="vc_general vc_tta vc_tta-accordion vc_tta-color-white vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-no-fill clearfix faq-accordion">
            <div class="vc_tta-panels-container">
                <div class="vc_tta-panels">
                    <div class="vc_tta-panel" id="1458664012912-2ddbd332-3cd8" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664012912-2ddbd332-3cd8" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">3. Ut est felis,
                                    ultricies at placerat id, ultrices id ante. Sed pulvinar?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664416829-7adc69fc-eff6" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664416829-7adc69fc-eff6" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">4. Curabitur
                                    dictum justo quis urna iaculis sagitatis?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel vc_active" id="1458664415977-1a6fcf24-9f52" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664415977-1a6fcf24-9f52" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">5. Aliquam aliquam
                                    porta nibh. Maecenas iaculis lectus ex? </span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664415252-122b5108-b4a7" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664415252-122b5108-b4a7" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">6. Morbi ut diam
                                    urna. Nam in tellus nec dui vestibulum ultrices. Nam commodo mauris a enim dapibus,
                                    id rhoncus nunc laoreet?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664414681-ea9d94f5-1179" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664414681-ea9d94f5-1179" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">7. Pellentesque
                                    consequat justo diam, ut lacinia libero accumsan?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664414076-c93dd2ee-3991" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664414076-c93dd2ee-3991" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">8. Nam commodo
                                    mauris a enim dapibus, id rhoncus nunc laoreet. Nunc lacinia cursus nisl quis
                                    rhoncus?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664408227-d8bfed31-7ad7" data-vc-content=".vc_tta-panel-body">
                        <div class="vc_tta-panel-heading">
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a
                                href="#1458664408227-d8bfed31-7ad7" data-vc-accordion=""
                                data-vc-container=".vc_tta-container"><span class="vc_tta-title-text">9. Ut in dui
                                    risus. Etiam turpis sapien, tincidunt quis dui quis, dapibus pretium orci?</span><i
                                    class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Suspendisse cursus, nisl at venenatis malesuada, ex tortor vestibulum arcu, quis
                                        imperdiet neque eros quis nunc. Nulla facilisi. Mauris vitae volutpat massa. Cras
                                        euismod odio eget ex eleifend ullamcorper. In sodales turpis turpis, vel commodo
                                        nisi sagittis eu. Proin nec laoreet ex. Aliquam efficitur lacus vitae elit maximus
                                        pretium. Nam auctor rhoncus justo vel convallis. In convallis ex turpis, ac eleifend
                                        tellus ultrices sit amet. Fusce a quam a urna sollicitudin vestibulum viverra vel
                                        felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices Praesent
                                        porttitor metus nec molestie placerat. Donec augue erat, fermentum nec pellentesque
                                        non.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
