<template>
<v-layout wrap style="background: url('/storage/web/containers.jpg');background-position: center;background-attachment: fixed;align-items: center;">
    <v-flex sm6>
        <div class="vc_column-inner vc_custom_1459030179383">
            <div class="wpb_wrapper">
                <div class="wpb_text_column wpb_content_element">
                    <div class="wpb_wrapper" style="margin-right: 30px;">
                        <p style="margin: 0px; text-align: right; font-size: 44px; color: #0076c0; line-height: 35px;"><b>Warehousing (3PL) </b><br>
                            <b>Frequently asked questions</b></p>
                    </div>
                </div>
            </div>
        </div>
    </v-flex>
    <v-flex sm6 style="background: rgb(0, 118, 192);color: #fff;padding: 10px;">
        <div class="mobile-padding-none wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
            <div class="vc_column-inner vc_custom_1459030221178">
                <div class="wpb_wrapper">
                    <!-- <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="content-widget-title text-left">
                                        <h3 style="color:#fff;">Warehousing (3PL) - Frequently asked questions</h3>
                                    </div>
                                    <v-divider></v-divider>
                                    <div class="wpb_text_column wpb_content_element vc_custom_1458572845492">
                                        <div class="wpb_wrapper">
                                            <p><span style="color: #ffffff; font-size: 18px;">What is 3PL?</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-25 vc_custom_1459360349844 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458572363524">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom50px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;">
                                            <span>1.</span></div>
                                        <h3 style="color:#ffffff;">What is 3PL? 3PL = 3rd Party Logistics</h3>
                                        <p style="color:#ffffff;font-size: 11.2px;">3PL (3rd Party Logistics) is the outsourcing of a company’s warehousing, fulfillment and/or transportation services to a 3rd party company.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-50 vc_custom_1459360415350 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;">
                                            <span>2.</span></div>
                                        <h3 style="color:#ffffff;"> How are the goods stored?</h3>
                                        <p style="color:#ffffff;font-size: 11.2px;">Warehousing depends entirely on the goods, but generally EUR and FIN pallets are stored on pallet shelves or mass storage places. Smaller quantities (boxes/containers) can be stored on small item shelves.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-0-75 vc_custom_1459360419402 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;">
                                            <span>3.</span></div>
                                        <h3 style="color:#ffffff;">I would like to use your warehousing service – how can this be done?</h3>
                                        <p style="color:#ffffff;font-size: 11.2px;">Our sales team will analyse your space requirements and the needed operational model. The services are priced on a customer-specific basis using this basic information. Please, contact us.
</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left animate anim-fadeIn animate-delay-1 vc_custom_1459360368453 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px">
                                        <div class="icon-list-number" style="border-color:#ffffff;color:#ffffff;">
                                            <span>4.</span></div>
                                        <h3 style="color:#ffffff;">How should the good be labelled? Can you do the labelling at the warehouse?</h3>
                                        <p style="color:#ffffff;font-size: 11.2px;">Yes, we can take care of the labelling. Value-added services can be added to the stored products before they are sent to the customer.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid animate anim-fadeIn animate-delay-1-25 animated fadeIn">
                        <div class="wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458573042272">
                                <div class="wpb_wrapper">
                                    <v-btn color="white" flat style="border: 1px solid;">
                                        <router-link to="/faqs" style="color: #fff;">Other Questions</router-link>
                                    </v-btn>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </v-flex>
</v-layout>
</template>
