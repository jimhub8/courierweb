<template>
    <div data-vc-full-width="true" data-vc-full-width-init="true"
    class="vc_row wpb_row vc_row-fluid backgroundtopleft vc_custom_1459253415759 vc_row-has-fill vc_row-o-equal-height vc_row-flex"
    style="position: relative; left: 0px; box-sizing: border-box; width: 1583px; padding-left: 0px; padding-right: 0px;background:  url('/storage/web/form-bg.png');align-items: center  ;height: 400px;background-attachment: fixed;background-position: center;padding: 10px;height: 100%;background-color:#0076c0 !important;">
    <div class="backgroundbottomleft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
        <div class="vc_column-inner vc_custom_1459253199271">
            <div class="wpb_wrapper"></div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner vc_custom_1459252455863">
            <div class="wpb_wrapper">
                <div
                    class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left vc_custom_1459243899235 vc_row-o-equal-height vc_row-flex">
                    <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
                        <div class="vc_column-inner vc_custom_1459243702399">
                            <div class="wpb_wrapper">
                                <div class="wpb_text_column wpb_content_element vc_custom_1464093194730">
                                    <div class="wpb_wrapper">
                                        <p
                                            style="text-align: right; margin-bottom: 0px; font-size: 49px; line-height: 44px; letter-spacing: -0.25px;">
                                            <span style="color: #ffffff;">get a&nbsp;quote</span><br> <span
                                                style="color: #ffffff;"> <strong>for&nbsp;best price</strong></span><br>
                                            <span style="color: #ffffff;"> <strong>and service</strong></span></p>
                                    </div>
                                </div>
                                <div class="wpb_text_column wpb_content_element vc_custom_1459244363341">
                                    <div class="wpb_wrapper">
                                        <h3 style="color: #3c5e74; font-size: 17px; margin: 0px;"><span
                                                style="color: #ffffff;"><strong>FILL THE FORM AND GET A
                                                    QUOTE</strong></span></h3>
                                    </div>
                                </div>





                                <div role="form" class="wpcf7" id="wpcf7-f93-p12-o1" lang="en-US" dir="ltr">
                                    <div class="screen-reader-response"></div>
                                    <Section6></Section6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import Section6 from './Section6';
export default {
    components: {
        Section6
    }
}
</script>

<style scoped>
.vc_custom_1459253199271 {
  padding-top: 250px !important;
  padding-bottom: 250px !important;
  background-image: url(/storage/web/form-left-layer.png) !important;
  background-position: center !important;
  background-repeat: no-repeat !important;
  background-size: contain !important;
}
.getaquote input[type="submit"] {
  background: #f00 !important;
}

.getaquote input[type="submit"]:hover {
  background: #fff !important;
  color: #000 !important;
}

  .vc_row.vc_row-flex {
      width: 100% !important;
  }
@media only screen and (max-width: 768px) {
  .vc_row.vc_row-flex {
      width: 100% !important;
  }
  .vc_row  .backgroundbottomleft   {
    height: 300px !important;
    margin-top: -130px !important;
}
}
</style>
 