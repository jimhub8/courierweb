<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid container vc_custom_1463481298482 vc_row-o-content-bottom vc_row-flex">
        <div class="wpb_column vc_column_container vc_col-sm-8">
            <div class="vc_column-inner vc_custom_1459257273110">
                <div class="wpb_wrapper">
                    <div class="wpb_text_column wpb_content_element vc_custom_1459351568009">
                        <div class="wpb_wrapper">
                            <p>
                                <span class="wow fadeIn" style="color: rgb(0, 118, 192); font-size: 36px;"  data-wow-duration="700ms" data-wow-delay="300ms">
                                    <strong style="font-size: 28px;">Our pickup and delivery service can help your business and give you time back to focus on what matters most. </strong></span></p>
                            <p class="wow fadeIn" style="color: #808080;" data-wow-duration="700ms" data-wow-delay="400ms">
                                Are you ready to improve your current same-day and overnight delivery methods? Using a professional pickup and delivery service can take your business to the next level. Our Local pickup and delivery services can be surprisingly affordable, often offering upfront pricing based on distance traveled and urgency instead of on package dimensions.</p>
                            <p class="wow fadeIn" style="color: #808080;" data-wow-duration="700ms" data-wow-delay="800ms">
                                As your business grows and your client base increases, the last thing you should be worried about is the well being of your important packages and the potential of spending money and time to replace damaged goods. At the end of the day, your customer service is at stake. You will want to present your business in the right light, at all times. We help establish the foundation for you to build a positive rapport with your customers and colleagues. Our real-time tracking capabilities and up-to-the-minute ETAs will keep you in the loop during the entire delivery process. You’ll also receive signature verification emails once your item has been delivered so that you know it made it there safe and on time. 
                            </p>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458921638091">
                        <div class="wpb_column vc_column_container vc_col-sm-3">
                            <div class="vc_column-inner vc_custom_1459351601091">
                                <div class="wpb_wrapper">
                                    <div class="icon-list center-block big wow fadeInLeft" data-wow-duration="700ms" data-wow-delay="1.2s">
                                        <div class="icon-list-icon" style="border-color:rgb(0, 118, 192);color:rgb(0, 118, 192);border-width:2px;">
                                            <i class="far fa-plus-square"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=" wpb_column vc_column_container vc_col-sm-3">
                            <div class="vc_column-inner vc_custom_1459351623363">
                                <div class="wpb_wrapper">
                                    <div class="icon-list center-block big wow fadeInLeft" data-wow-duration="700ms" data-wow-delay="1.5s">
                                        <div class="icon-list-icon" style="border-color:rgb(0, 118, 192);color:rgb(0, 118, 192);border-width:2px;"><i
                                                class="fas fa-paperclip" ></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-3">
                            <div class="vc_column-inner vc_custom_1459351635877">
                                <div class="wpb_wrapper">
                                    <div class="icon-list center-block big wow fadeInLeft" data-wow-duration="700ms" data-wow-delay="1.8s">
                                        <div class="icon-list-icon" style="border-color:rgb(0, 118, 192);color:rgb(0, 118, 192);border-width:2px;">
                                            <i class="fas fa-bars"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-3">
                            <div class="vc_column-inner vc_custom_1459351648649">
                                <div class="wpb_wrapper">
                                    <div class="icon-list center-block big wow fadeInLeft" data-wow-duration="700ms" data-wow-delay="2.2s">
                                        <div class="icon-list-icon" style="border-color:rgb(0, 118, 192);color:rgb(0, 118, 192);border-width:2px;">
                                            <i class="fas fa-object-ungroup"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wow fadeInRight wpb_column vc_column_container vc_col-sm-4 vc_col-lg-4 vc_col-md-4 vc_hidden-xs" data-wow-duration="700ms" data-wow-delay="2.5s">
            <div class="vc_column-inner">
                <div class="wpb_wrapper">
                    <div class="wpb_single_image wpb_content_element vc_align_left vc_custom_1463481571850">
                        <figure class="wpb_wrapper vc_figure">
                            <div class="vc_single_image-wrapper vc_box_border_grey"><img width="416" height="439"
                                    src="/storage/web/home3-layer.jpg"
                                    class="vc_single_image-img attachment-full" alt=""
                                    sizes="(max-width: 416px) 100vw, 416px" style="margin-bottom: 100px;"></div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
