<template>
    <div>
        
                    <div class="testimonial-modern-widget none">
                        <!-- <div class="testimonial-modern-widget-navigation"> <a class="testimonial-modern-widget-prev"><i
                                    class="fas fa-long-arrow-left"></i></a> <a class="testimonial-modern-widget-next"><i
                                    class="fas fa-long-arrow-right"></i></a></div> -->
                        <div class="owl-carousel-testimonial-modern-156311650 owl-theme owl-carousel owl-loaded">
                            <div class="owl-stage-outer">
                                <div class="owl-stage row" style="transform: translate3d(-1205px, 0px, 0px); transition: all 0s ease 0s; width: 3615px;">
                                    <div class="owl-item cloned" style="width: 537.5px; margin-right: 65px;">

                                    </div>
                                    <div class="owl-item cloned" style="width: 537.5px; margin-right: 65px;">

                                    </div>
                                    <div class="owl-item active col-md-2" style="width: 537.5px; margin-right: 65px;">
                                        <div class="item alternative anim-fadeInLeft">
                                            <div class="image"><img
                                                    src="/storage/web/zuri.jpg"
                                                    alt="Customer"></div>
                                                <div class="testimonial-modern-item-name"><span class="name">LILLY MACHARIA,
                                                </span><span class="company">ZURI KIDS</span></div>
                                                <div class="testimonial-modern-item-content">
                                                    <p>Boxleo Courier & Fulfillment Services provides
                                                        us with a quality express courier services, with
                                                        products reaching our customers in plenty of
                                                        time, while offering great value for money. I would
                                                        recommend them to anyone.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item active col-md-2" style="width: 537.5px; margin-right: 65px;">
                                            <div class="item alternative anim-fadeInRight">
                                                <div class="image"><img
                                                    src="/storage/web/oloo.jpg"
                                                    alt="Customer"></div>
                                                    <div class="testimonial-modern-item-name"><span class="name">OLIVER WEKESA,
                                                </span><span class="company">OLOO COLLECTION</span></div>
                                                    <div class="testimonial-modern-item-content">
                                                        <p>Boxleo Courier & Fulfillment
                                                            Services has helped us save time
                                                            during key decision-making
                                                            processes and implement an
                                                            efficient sample delivery service to
                                                            all our customers.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
    </div>
</template>