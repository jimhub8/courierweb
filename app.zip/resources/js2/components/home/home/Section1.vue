<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid container">
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029076462">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="image" style="background-image:url(/storage/web/feature-1.jpg);">
                        </div>
                        <div class="feature-box-content">
                            <div class="feature-box-icon"><i class="fas fa-shield-alt"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms">SECURE & INSURED COURIER</h4>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">Experience secure delivery to the addressee only, real time tracking & a transparent chain of custody so you can see where your delivery is throughout its transit.</p>
                            <div class="button">
                                <v-btn  class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">more</router-link>
                                </v-btn>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029085473">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="feature-box-content bottom">
                            <div class="feature-box-icon"><i class="fas fa-shield-alt"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms">FAST AND REAL-TIME TRACKING</h4>
                            <br>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">Track your deliveries and reduce the customer calls dramatically with an automatic real-time tracking system.</p>
                            <div class="button">
                                <v-btn  class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">more</router-link>
                                </v-btn>

                            </div>
                        </div>
                        <div class="image bottom" style="background-image:url(/storage/web/feature-2.jpg);">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459029096986">
                <div class="wpb_wrapper">
                    <div class="feature-box themethreecolor">
                        <div class="image" style="background-image:url(/storage/web/feature-3.jpg);">
                        </div>
                        <div class="feature-box-content">
                            <div class="feature-box-icon"><i class="fas fa-undo"></i></div>
                            <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="500ms">SPACIOUS WAREHOUSES</h4>
                            <p class="wow fadeInUp" data-wow-duration="600ms" data-wow-delay="1s">We offer more than 22,000 square meters of space. Our warehouses are temperature-controlled enabling us to accommodate sensitive products as well.</p>
                            <div class="button">
                                <v-btn  class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1.5s" round style="border: 1px solid;margin: auto;" flat color="white">
                                    <router-link to="/faqs" style="color: #fff;">more</router-link>
                                </v-btn>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
