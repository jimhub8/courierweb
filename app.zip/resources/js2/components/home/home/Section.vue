<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid container vc_custom_1463481277180 vc_row-o-content-bottom vc_row-flex">
        <div class="cargo-query-form-mobile-bottom-content wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1459090040842">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458302766138">
                        <div class="animate anim-fadeIn animate-delay-0 wpb_column vc_column_container vc_col-sm-12 animated fadeIn">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;">
                                            <i class="fas fa-bus wow fadeInLeft" data-wow-duration="400ms" data-wow-delay="700ms"></i>
                                        </div>
                                        <h3 style="font-size:18px;color:#0ba6dd;" class="wow fadeInDown" data-wow-duration="700ms" data-wow-delay="800ms">Express Courier</h3>
                                        <p class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1200ms" style="font-size:12px;color:#858585;">We offer pickup and same-day delivery, on time, every time – across town or across the country – whether on-demand, scheduled or overnight</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="animate anim-fadeIn animate-delay-0-25 wpb_column vc_column_container vc_col-sm-12 animated fadeIn">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;">
                                            <i class="fas fa-shield-alt wow fadeInLeft" data-wow-duration="400ms" data-wow-delay="700ms"></i>
                                        </div>
                                        <h3 style="font-size:18px;color:#0ba6dd;" class="wow fadeInDown" data-wow-duration="700ms" data-wow-delay="800ms">Order Fulfillment</h3>
                                        <p class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1200ms" style="font-size:12.7px;color:#858585;">We palletize shipments and orders for delivery to your stores and customers & pick, pack &  ship on time.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="animate anim-fadeIn animate-delay-0-50 wpb_column vc_column_container vc_col-sm-4 animated fadeIn">
            <div class="vc_column-inner">
                <div class="wpb_wrapper">
                    <div class="wpb_single_image wpb_content_element vc_align_center vc_custom_1458921389836">
                        <figure class="wpb_wrapper vc_figure">
                            <div class="vc_single_image-wrapper vc_box_border_grey"><img width="376" height="383"
                                    src="/storage/web/home3-services.jpg"
                                    class="vc_single_image-img attachment-full" alt=""
                                    srcset="/storage/web/home3-services.jpg 376w, /storage/web/home3-services-295x300.jpg 295w"
                                    sizes="(max-width: 376px) 100vw, 376px"></div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner vc_custom_1458921180932">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458302766138">
                        <div class="animate anim-fadeIn animate-delay-0-75 wpb_column vc_column_container vc_col-sm-12 animated fadeIn">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i
                                                class="fas fa-external-link-square-alt wow fadeInLeft" data-wow-duration="400ms" data-wow-delay="700ms"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;" class="wow fadeInDown" data-wow-duration="700ms" data-wow-delay="800ms">Medical Courier</h3>
                                        <p style="font-size:12.7px;color:#858585;" class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1200ms">From medical supplies to samples, our team is equipped to deliver your items, both big & small, on-demand and scheduled route.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="animate anim-fadeIn animate-delay-1 wpb_column vc_column_container vc_col-sm-12 animated fadeIn">
                            <div class="vc_column-inner">
                                <div class="wpb_wrapper">
                                    <div class="icon-list marginbottom30px big">
                                        <div class="icon-list-icon" style="border-color:#0ba6dd;color:#0ba6dd;"><i
                                                class="fas fa-cube wow fadeInLeft" data-wow-duration="400ms" data-wow-delay="700ms"></i></div>
                                        <h3 style="font-size:18px;color:#0ba6dd;" class="wow fadeInDown" data-wow-duration="700ms" data-wow-delay="800ms">Third Party Logistics</h3>
                                        <p style="font-size:12.7px;color:#858585;" class="wow fadeInUp" data-wow-duration="700ms" data-wow-delay="1200ms">Boxleo has partnered with several foreign logistics companies to be the fastest link between them and their customers.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
