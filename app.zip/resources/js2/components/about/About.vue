<template>
<div>
    <div class="page-content-banner" style="background-image:url('/storage/web/default-page-baner.jpg');"></div>
    <div class="text-center container" id="about">
        <div class="text-center" id="header">
            <h2>OUR STORY</h2>
            <p style="text-align: center;">For more than year, Boxleo Courier & Fulfillment Services has been meeting Kenya’s delivery needs with excellence, precision and friendly service.</p>
        </div>
        <v-layout wrap id="body" style="margin-top: 40px;">
            <v-flex sm6>
                <p style="text-align: left;">Boxleo Courier & Fulfillment Services was founded in 2018 with the dream of perfecting logistics and order fulfillment. </p>
                <p style="text-align: left;">We continue to grow while delivering the most tech-savvy enterprise fulfillment experience with a personal touch. Our home base in Nairobi has expanded with locations in Mombasa, Kisumu, and Nakuru to amplify fast, competitive shipping speeds with same-day delivery options. We are always on the cutting-edge with the best technology and systems to help your business grow.</p>

                <p style="text-align: left;">That’s because we understand how critical your delivery is to you and your business. As a delivery service, we know our couriers are a representation of you, and we aim to represent you well.
                </p>

                <p style="text-align: left;"></p>

                <p style="text-align: left;">Boxleo Courier and Fulfillment Services’ Founder is committed to integrity and excellence. And when leadership is committed to these goals, it shows. We are proud of high client loyalty and can’t wait to add more to our ever-growing family.</p>

            </v-flex>
            <v-flex sm6 style="background: url('/storage/web/Ware-house.png');background-attachment: fixed;background-position: center;">
            </v-flex>
        </v-layout>

        <v-layout wrap style="margin-top: 40px;">
            <v-flex sm5>
                <v-layout wrap>
                    <v-flex sm12>
                        <div class="services-box-icon icontitlecenterparagraphleft">
                            <i class="far fa-thumbs-up"></i>
                        </div>
                        <h3 style="text-center">OUR MISSION</h3>
                        <p style="text-align: left;">Establish a standard and world – class courier and delivery services company that will make available a wide range of services and products as it relates to the service offerings in the global courier and delivery services industry at affordable prices to the residence of Kenya, and other locations in the globe where we intend operating from.</p>
                    </v-flex>
                    <v-flex sm12>
                        <div class="services-box-icon icontitlecenterparagraphleft">
                            <i class="fas fa-low-vision"></i>
                        </div>
                        <h3 style="text-center">OUR VISION</h3>
                        <p style="text-align: left;">Build a courier and delivery services company that will have active presence all over Africa and the globe.</p>
                    </v-flex>
                </v-layout>
            </v-flex>
            <v-flex sm6 offset-sm-1>
                <div class="services-box-icon icontitlecenterparagraphleft"><i class="fa fa-arrows-alt"></i></div>
                <h3 style="text-center">OUR CORE VALUES</h3>
                <p style="text-align: left;">
                    <br> <b>We mean what we say</b> <br>
                    When we commit something to you, we make it happen.
                    <br> <b>Honesty. Always.</b> <br>
                    We believe in honest dealings, from start to finish.
                    <br> <b>People</b> <br>
                    We care about our people and the people we serve.
                    <br> <b>Quality, friendly service</b> <br>
                    We believe in keeping service personal and kind. Our friendly team is ready 24/7
                    <br> <b>Technology</b> <br>
                    We stay ahead of the technology curve and are always looking for ways to improve. Our first year of operation saw paper orders and phone calls. Today we offer online order entry, delivery tracking and much more.
                    <br> <b>Spiritual</b> <br>
                    At Boxleo Courier and Fulfillment Services, we strive to honor the faiths of all religions in all we do - from pick-up to drop-off and everything in between.

                </p>
            </v-flex>
        </v-layout>
    </div>

    <Chronological></Chronological>
    <!-- <v-layout wrap style="background: url('/storage/web/slider-2-1.jpg');background-attachment: fixed;background-position: center;">
        <v-flex sm12 xs12>

        </v-flex>
        <v-flex xs12 sm12 style="background: #0076c0;align-items: stretch;padding:30px; padding: 30px 200px 20px 60px;">
            <h2 style="font-size: 16px;color: #feffff;text-align: left" class="vc_custom_heading vc_custom_1458482739639">CHRONOLOGICAL PROJECTIONS</h2>

            <div class="chronologyyears-content" style="background:#ffffff;">
                <div class="year-block">2018</div>
                <div class="separate"></div>
                <div class="year-block">2019</div>
                <div class="separate"></div>
                <div class="year-block">2020</div>
                <div class="separate"></div>
                <div class="year-block">2021</div>
                <div class="separate"></div>
                <div class="year-block">2022</div>
                <div class="separate"></div>
                <div class="year-block">2023</div>
                <div class="separate"></div>
            </div>
            <div class="vc_empty_space" style="height: 26px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-793511340" class="progress-wrap progress" data-progress-percent="10" style="border-color:#ffffff;">
                        <div id="progress-bar-793511340" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 10%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2018, </span><span
                            class="text">Orders processed.</span></div>
            </div>
            <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-1791272075" class="progress-wrap progress" data-progress-percent="25" style="border-color:#ffffff;">
                        <div id="progress-bar-1791272075" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 25%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2019, </span><span class="text">Orders processed.</span></div>
            </div>
            <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-1735158128" class="progress-wrap progress" data-progress-percent="38" style="border-color:#ffffff;">
                        <div id="progress-bar-1735158128" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 38%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2020, </span><span
                            class="text">Orders processed. APIs Integrated.</span></div>
            </div>
            <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-349986507" class="progress-wrap progress" data-progress-percent="53" style="border-color:#ffffff;">
                        <div id="progress-bar-349986507" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 53%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2021, </span><span class="text">Orders processed. APIs Integrated.</span></div>
            </div>
            <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-6551315360" class="progress-wrap progress" data-progress-percent="80" style="border-color:#ffffff;">
                        <div id="progress-bar-6551315360" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 80%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2022, </span><span class="text">Orders processed. APIs Integrated. Pickup Locations.</span></div>
            </div>
            <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
            <div class="chronologyitem-bar">
                <div class="progress-content">
                    <div id="progress-wrap-9036800100" class="progress-wrap progress" data-progress-percent="100" style="border-color:#ffffff;">
                        <div id="progress-bar-9036800100" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 100%;"></div>
                    </div>
                </div>
                <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2023, </span><span
                            class="text">Orders processed. APIs Integrated. Pickup Locations.</span></div>
            </div>
        </v-flex>
    </v-layout> -->
    <div class="container">
        <h3 class="text-center" style="font-size: 25px;">If you aren’t ahead, you’re behind. </h3>
        <p>That’s what we believe when it comes to technology. Our management team which boasts more than a year of combined logistics experience is always focused on staying ahead of the logistics technology curve. We believe that the best service means the best technology. That’s why we offer our online order entry, and real-time tracking – just to name a few. Our 24/7 dispatch team utilizes state of the art logistics technology and is in constant communication with our drivers. When you choose Boxleo Courier & Fulfillment Services, you can trust that your delivery is receiving the utmost care and focus.
            While technology is critical to our success, we also believe in offering it all. You can utilize our website or go the old-fashioned way and give us a call. A friendly customer service representative will greet you (yes, a person and not an automated response!) and help you set up an order. From technology to personalized service, our team truly offers it all.
        </p>

    </div>
    <div class="vc_row wpb_row vc_row-fluid bgfixed vc_custom_1459258163844 vc_row-has-fill" style="background:  url('/storage/web/home3-bg.jpg');background-attachment: fixed;background-position: center;">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner vc_custom_1458318373653">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid container vc_custom_1458318277502">
                        <div class="wpb_column vc_column_container vc_col-sm-2" v-for="(counter, index) in count" :key="index">
                            <div class="vc_column-inner vc_custom_1458318908638">
                                <div class="wpb_wrapper">
                                    <div class="numbermator">
                                        <h3 style="color:#ffffff;">
                                            <!-- <div class="counter scounter3866577152" data-last="256">256</div> -->
                                            <countTo :startVal='counter.start' :endVal='counter.end' :duration='4000'></countTo>
                                        </h3>
                                        <h4 style="color:#ffffff;">{{ counter.text }}</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import countTo from "vue-count-to";
import Chronological from './about/Chronological'
export default {
  components: {
    countTo,
    Chronological,
  },
  data() {
    return {
      count: [
        {
          start: 0,
          end: 253,
          text: "CUSTOMERS SERVED"
        },
        {
          start: 0,
          end: 24,
          text: "DELIVERY PERSONEL"
        },
        {
          start: 0,
          end: 9378,
          text: "ORDERS PROCESSED"
        },
        {
          start: 0,
          end: 67,
          text: "PICKUP LOCATIONS"
        },
        {
          start: 0,
          end: 76,
          text: "E-COMMERCE INTEGRATED"
        },
        {
          start: 0,
          end: 2,
          text: "WAREHOUSE LOCATIONS"
        }
      ]
    };
  },

  beforeRouteLeave(to, from, next) {
    eventBus.$emit("loaderEvent");
    next();
  }
};
</script>

<style scoped>
#about #header h2::before {
  content: "";
  display: inline-block;
  width: 15px;
  height: 15px;
  transform: rotate(45deg);
  margin-right: 13px;
  border-width: 2px;
  border-style: solid;
  border-color: rgb(11, 166, 221);
  border-image: initial;
  transition: all 0.3s ease 0s;
}

#about #header p::after {
  max-width: 75px;
  height: 1px;
  content: "";
  display: block;
  background: rgb(11, 166, 221);
  margin: 19px auto 0px;
}

#about #header p {
  font-weight: 700;
  font-size: 18px;
  color: rgb(162, 162, 162);
  margin: 14px 0px 0px;
}

#about #body p {
  font-size: 17px;
  margin-bottom: 33px;
}

.services-box-icon.icontitlecenterparagraphleft {
  margin-left: auto;
  margin-right: auto;
}

.services-box-icon {
  width: 56px;
  height: 56px;
  line-height: 51px;
  font-size: 25px;
  padding-left: 0px;
}

.services-box-icon {
  width: 77px;
  height: 77px;
  line-height: 77px;
  font-size: 35px;
  color: rgb(11, 166, 221);
  text-align: center;
  margin-bottom: 30px;
  transform: rotate(45deg);
  margin-left: 14px;
  margin-top: 14px;
  border-radius: 5px;
  border-width: 2px;
  border-style: solid;
  border-color: rgb(11, 166, 221);
  border-image: initial;
  transition: all 0.3s ease 0s;
}

.services-box-icon i {
  transform: rotate(-45deg);
}

.chronologyitem-text .year {
  font-size: 14.5px;
  font-family: "Source Sans Pro";
  line-height: 1.7em;
  font-weight: 700;
}
</style>
