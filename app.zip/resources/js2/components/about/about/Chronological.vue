<template>
<div>
    <div class="vc_row wpb_row vc_row-fluid vc_row-o-equal-height vc_row-flex" style="background: url('/storage/web/slider-2-1.jpg');background-attachment: fixed;background-position: center;">
        <div class="bgfixed backgroundcentercenter wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill">
            <div class="vc_column-inner vc_custom_1458942589240">
                <div class="wpb_wrapper">
                    <div class="wpb_single_image wpb_content_element vc_align_left imageabsolute-center-right">
                        <figure class="wpb_wrapper vc_figure">
                            <div class="vc_single_image-wrapper vc_box_border_grey">
                                <img width="55" height="114" src="/storage/web/about-arrow-image.png" class="vc_single_image-img attachment-full" alt="">
                            </div>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill" style="background: #0076c0;">
            <div class="vc_column-inner vc_custom_1458483065334">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid full-area-container-content-left vc_custom_1458941842529">
                        <div class="mobile-padding-none wpb_column vc_column_container vc_col-sm-12">
                            <div class="vc_column-inner vc_custom_1458942008831">
                                <div class="wpb_wrapper">
                                    <h2 style="font-size: 16px;color: #feffff;text-align: left" class="vc_custom_heading vc_custom_1458482739639">CHRONOLOGICAL PROJECTIONS</h2>
                                    <div class="chronologyyears-content" style="background:#ffffff;">
                                        <div class="year-block">2018</div>
                                        <div class="separate"></div>
                                        <div class="year-block">2019</div>
                                        <div class="separate"></div>
                                        <div class="year-block">2020</div>
                                        <div class="separate"></div>
                                        <div class="year-block">2021</div>
                                        <div class="separate"></div>
                                        <div class="year-block">2022</div>
                                        <div class="separate"></div>
                                        <div class="year-block">2023</div>
                                        <div class="separate"></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 26px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-793511340" class="progress-wrap progress" data-progress-percent="10" style="border-color:#ffffff;">
                                                <div id="progress-bar-793511340" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 10%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2018, </span><span class="text">Orders processed.</span></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-1791272075" class="progress-wrap progress" data-progress-percent="25" style="border-color:#ffffff;">
                                                <div id="progress-bar-1791272075" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 25%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2019, </span><span class="text">Orders processed.</span></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-1735158128" class="progress-wrap progress" data-progress-percent="38" style="border-color:#ffffff;">
                                                <div id="progress-bar-1735158128" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 38%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2020, </span><span
                            class="text">Orders processed. APIs Integrated.</span></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-349986507" class="progress-wrap progress" data-progress-percent="53" style="border-color:#ffffff;">
                                                <div id="progress-bar-349986507" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 53%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2021, </span><span class="text">Orders processed. APIs Integrated.</span></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-6551315360" class="progress-wrap progress" data-progress-percent="80" style="border-color:#ffffff;">
                                                <div id="progress-bar-6551315360" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 80%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2022, </span><span class="text">Orders processed. APIs Integrated. Pickup Locations.</span></div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="chronologyitem-bar">
                                        <div class="progress-content">
                                            <div id="progress-wrap-9036800100" class="progress-wrap progress" data-progress-percent="100" style="border-color:#ffffff;">
                                                <div id="progress-bar-9036800100" class="progress-bar progress" style="background: rgb(255, 255, 255); width: 100%;"></div>
                                            </div>
                                        </div>
                                        <div class="chronologyitem-text" style="color:#ffffff;"><span class="year">-2023, </span><span class="text">Orders processed. APIs Integrated. Pickup Locations.</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<style scoped>
@media only screen and (max-width: 768px) {
    .vc_row.vc_row-flex>.bgfixed>.vc_custom_1458942589240 {
        height: 400px !important;
    }

    .vc_row.vc_row-o-equal-height>.vc_column_container[data-v-4475eea7] {
        height: auto;
    }
}
</style>
