<template>
<section class="bg-title-page p-t-50 p-b-40 flex-col-c-m">
    <div style="padding: 100px;">
        <h2 class="l-text2 t-center" style="color: #000;text-transform: none;">
            Box<span style="color: rgba(2, 234, 0, 0.58);">Leo</span>
        </h2>
        <p class="m-text13 t-center">
            Living in the future
        </p>
    </div>
</section>
</template>

<script>
export default {

}
</script>

<style scoped>
.bg-title-page {
    background-image: url(/storage/8.jpg) !important;
    background-attachment: fixed !important;
}

.bg-title-page {
    width: 100%;
    min-height: 239px;
    padding-left: 15px;
    padding-right: 15px;
    background-repeat: no-repeat;
    background-position: center 0;
    background-size: cover;
}

.l-text2 {
    font-family: Montserrat-Bold;
    font-size: 50px;
    color: white;
    line-height: 1.2;
    text-transform: uppercase;
}

.m-text13 {
    font-family: Montserrat-Regular;
    font-size: 18px;
    color: white;
    line-height: 1.8;
}

.t-center {
    text-align: center;
}

p {
    margin-bottom: 16px;
}

p {
    margin-top: 0;
    margin-bottom: 1rem;
}
</style>
