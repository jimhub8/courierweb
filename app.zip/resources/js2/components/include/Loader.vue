<template>
    <div class="loader-wrapper">
        <div class="sk-folding-cube">
            <div class="sk-cube1 sk-cube"></div>
            <div class="sk-cube2 sk-cube"></div>
            <div class="sk-cube4 sk-cube"></div>
            <div class="sk-cube3 sk-cube"></div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.sk-folding-cube .sk-cube:before {
    background-color: #0076c0;
}
</style>
