<template>
<div class="wpb_column vc_column_container vc_col-sm-4">
    <div class="vc_column-inner">
        <div class="wpb_wrapper">
            <div class="vc_row wpb_row vc_inner vc_row-fluid">
                <div class="wpb_column vc_column_container vc_col-sm-6">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                            <div class="content-widget-title smal text-left">
                                <h3 style="color:#ffffff;font-size:13px !important;">LOGISTIC PROCESS</h3>
                            </div>
                            <div class="vc_wp_custommenu wpb_content_element footermenu">
                                <div class="widget widget_nav_menu">
                                    <div class="menu-logistic-process-container">
                                        <ul id="menu-logistic-process" class="menu">
                                            <li id="menu-item-266" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-266"><a href="#">Order Fulfillment</a></li>
                                            <li id="menu-item-266" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-266"><a href="#">Expertise Services</a></li>
                                            <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="#">Packaging</a></li>
                                            <li id="menu-item-268" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-268"><a href="#">Transportation</a></li>
                                            <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="#">Delivery</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-6">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                            <div class="content-widget-title smal text-left">
                                <h3 style="color:#ffffff;font-size:13px !important;">SERVICES</h3>
                            </div>
                            <div class="vc_wp_custommenu wpb_content_element footermenu">
                                <div class="widget widget_nav_menu">
                                    <div class="menu-services-container">
                                        <ul id="menu-services" class="menu">
                                            <li id="menu-item-274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-274"><a href="http://demo.gloriathemes.com/wp/translogistic/airline-transportation/">Express Courier</a></li>
                                            <li id="menu-item-275" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-275"><a href="http://demo.gloriathemes.com/wp/translogistic/event-transportation/">Medical Courier</a></li>
                                            <li id="menu-item-276" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-42 current_page_item menu-item-276"><a href="http://demo.gloriathemes.com/wp/translogistic/land-transportation/">Refrigerated Transport</a></li>
                                            <li id="menu-item-277" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-277"><a href="http://demo.gloriathemes.com/wp/translogistic/maritime-transportation/">Warehousing</a></li>
                                            <li id="menu-item-278" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-278"><a href="http://demo.gloriathemes.com/wp/translogistic/railway-transportation/">Packaging</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<style scoped>
.content-widget-title:before {
    border: 2px solid #fff;
}
</style>
