<template>
<div class="footer-top">
    <div class="footer_widget footer_top_widget_page">
        <div class="container">
            <div class="row">
                <div class="vc_row wpb_row vc_row-fluid vc_custom_1458226603361 vc_row-has-fill" style="margin: auto;width: 100%;">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner vc_custom_1458225364896">
                            <div class="wpb_wrapper">
                                <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1458225356014">
                                    <div class="wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner vc_custom_1458226611802">
                                            <div class="wpb_wrapper">
                                                <div class="content-widget-title small text-left">
                                                    <h3 style="font-size:14px;">WORKING HOURS</h3>
                                                </div>
                                                <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                                <div class="contact-information alternative">
                                                    <div class="contact-information-row contact-information-custom-row">
                                                        <div class="contact-information-icon"><i class="fa fa-clock-o" style="color:#0ba6dd;"></i></div>
                                                        <div class="contact-information-content"><strong>Weekday Working Hours:</strong> 07:00 - 18:00<br><strong>Saturday Working Hours:</strong> 08:30 - 12:30</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpb_column vc_column_container vc_col-sm-4">
                                        <div class="vc_column-inner vc_custom_1458226615473">
                                            <div class="wpb_wrapper">
                                                <div class="content-widget-title small text-left">
                                                    <h3 style="font-size:14px;">ADDRESS INFORMATIONS</h3>
                                                </div>
                                                <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                                <div class="contact-information alternative">
                                                    <div class="contact-information-row contact-information-custom-row">
                                                        <div class="contact-information-icon"><i class="fa fa-map-marker" style="color:#0ba6dd;"></i></div>
                                                        <div class="contact-information-content"><strong>Head Office:</strong><small> Leomar Court, 2nd Floor, Suite No.8</small> <br><strong>Mombasa Office:</strong><small> Epic Business Park, Nyali</small></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <Section2></Section2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
import Section2 from "./Section1";
export default {
  components: {
    Section2
  }
};
</script>
