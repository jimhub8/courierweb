<template>
<div>
    <h3 style="font-size: 15px;color: #858585;text-align: left" class="vc_custom_heading vc_custom_1458565978208">WE MAKE YOUR LOGISTICS SMART</h3>
    <div class="wpb_text_column wpb_content_element">
        <div class="wpb_wrapper">
            <p>Based on the dimensions, sizes and destinations of your products - Boxleo Courier provides you, your business and your customer with smart and tailor-made logistic solutions. This will not only make the order process of your business very flexible, but it also allows your customer to have their orders delivered right the first time</p>
            <p>Cras vulputate neque commodo, dictum mauris ultrices, aliquam est. In hac habitasse platea
                dictumst. Praesent porttitor metus nec molestie placerat. Donec augue erat, fermentum nec
                pellentesque non, varius ut massa. Maecenas scelerisque.</p>
        </div>
    </div>

    <h3 style="font-size: 15px;color: #858585;text-align: left" class="vc_custom_heading vc_custom_1458565978208">BULK UPLOAD: MULTIPLE SOLUTIONS, JUST ONE CLICK</h3>
    <div class="wpb_text_column wpb_content_element">
        <div class="wpb_wrapper">
            <p>Another function of our system of which we’re very proud, is the ability to create very large logistic solutions with just one click. </p>
            <p>It’s called bulk upload and it will allow you, by uploading a spreadsheet (file: XLS, CSV), to import all your order data at once in your shipping account. So, instead of entering all details in manually (and have your intern experience a nervous breakdown), the system will order everything for you and automatically create the logistic solution your customers are served with best. </p>
            <p>Needless to say, this will make you save an enormous amount of time. </p>
        </div>
    </div>
    <h3 style="font-size: 15px;color: #858585;text-align: left" class="vc_custom_heading vc_custom_1458565978208">WANT TO KNOW MORE?</h3>
    <div class="wpb_text_column wpb_content_element">
        <div class="wpb_wrapper">
            <p>Do you want to integrate your systems with ours? <a href="/register" style="color: #0076c0;">Sign up for a free profile now!</a>  Having a profile <b>does not obligate you to do or send anything.</b></p>
        </div>
    </div>
</div>
</template>
