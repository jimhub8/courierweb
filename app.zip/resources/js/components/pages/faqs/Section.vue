<template>
<div>
                <p>In this section we list the most frequently asked ‘general’ questions. If you have a more specific question you can check one of the categories. Should you miss certain information or if you have any other questions, please let us know!</p>

    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>1. </span></div>
        <h3 style="color:#0ba6dd;">To which destinations am I able to ship with Boxleo?</h3>
        <p style="color:#a3a3a3;">
            We ship to all 47 counties of Kenya. We also  have agents across all East Africa and are currently very active in Tanzania, Uganda, Rwanda and Burundi.
        </p>
    </div>
    <v-divider></v-divider>
    <div class="vc_empty_space" style="height: 59px"><span class="vc_empty_space_inner"></span></div>
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>2.</span></div>
        <h3 style="color:#0ba6dd;">What happens after I've placed a booking?</h3>
        <p style="color:#a3a3a3;">After you’ve placed a booking, the consignment will be automatically posted to the selected carrier.</p>
    </div>
    <v-divider></v-divider>
    <div class="vc_empty_space" style="height: 35px"><span class="vc_empty_space_inner"></span></div>
    <div class="vc_tta-container" data-vc-action="collapse">
        <div class="vc_general vc_tta vc_tta-accordion vc_tta-color-white vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-no-fill clearfix faq-accordion">
            <div class="vc_tta-panels-container">
                <div class="vc_tta-panels">
                    <div class="vc_tta-panel" id="1458664012912-2ddbd332-3cd8" data-vc-content=".vc_tta-panel-body">
                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;margin-top: 40px;"><span>3.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">Which carriers does  Boxleo offer?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>We offer the services of the world’s leading carriers and transporters. Depending on the specifications, features and destination of your shipment, we can quote you very interesting rates as well as – in general - the best offer. We present a complete range of services for each quote application.
                                    We state the best service first, followed by all other possible options. This is especially helpful if you want short lead-times (e.g. the next day before 09.00, 10.00 of 12.00 noon)

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664416829-7adc69fc-eff6" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>4.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">What are your office hours?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>You can call us from Monday to Friday, 07:00 - 18:00 and on Saturday from 08:30 - 12:30. We are closed on Sunday.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664415977-1a6fcf24-9f52" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>5.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container">
                                <span class="vc_tta-title-text" style="color:#0ba6dd;">What is your phone number?
                                </span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Our phone number is +254 743 332 743</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664415252-122b5108-b4a7" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;margin-top: 30px;"><span>6.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">How can I contact  Boxleo?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>You can contact us in different ways:
                                        By phone: +254 743 332 743.
                                        You can also use our contact form. After you submitted a support request, we will contact you as soon as possible</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664414681-ea9d94f5-1179" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>7.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">Is  Boxleo a registered company?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Yes. We are a private company and are registered under the Business Registration Ordinance in Kenya.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664414076-c93dd2ee-3991" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>8.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">Do you have a list of products that can’t be sent with  Boxleo?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Yes. Please check our Prohibited Goods section.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664408227-d8bfed31-7ad7" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;margin-top: 20px;"><span>9.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">Does  Boxleo offer air and ocean freight services?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Yes! You can use Boxleo to receive a quote from one of our specially selected partners. You can use the „Request Custom Quote” button to send us detailed information about your shipment.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
