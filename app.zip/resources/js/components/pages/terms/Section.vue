<template>
<div>
    <!-- <p>What kinds of personal information does Boxleo Courier & Fulfillment Services collect and hold?</p> -->

    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>1. </span></div>
        <h3 style="color:#0ba6dd;">IN THESE TERMS AND CONDITIONS:</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">“Courier” shall mean ‘BOXLEO COURIER & FULFILLMENT SERVICES’, its servants, agents, and Sub-Contractors.</span></li>
            <li><span style="color: #858585; font-weight: 500;">“Customer” shall mean the person or entity, or as servants or agents, entering into this contract with the Courier.</span></li>
            <li><span style="color: #858585; font-weight: 500;">“Sub-Contractor” shall mean and include the following:</span></li>
            <small>a. Any person, business, firm or company with whom the Courier may arrange for the carriage of any goods the subject of this contract;</small> <br> <br>
            <small>b. Any person who is now or later a servant, agent, employee or Sub-Contractor of any other persons referred to in (a) above.</small> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>2. </span></div>
        <h3 style="color:#0ba6dd;">COURIER IS NOT A COMMON CARRIER.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">2.1 The Courier is not a common carrier and will accept no liability as such.</span></li>
            <li><span style="color: #858585; font-weight: 500;">2.2 All goods or articles are carried or transported and all storage and other services are performed by the Courier subject to these conditions.</span></li>
            <li><span style="color: #858585; font-weight: 500;">2.3 The Courier reserves the right to refuse to transport any goods for any person, firm or company at its discretion without being bound to give any reason for such refusal.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>3. </span></div>
        <h3 style="color:#0ba6dd;">RIGHT TO SUB-CONTRACT.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">3.1 The Customer authorises the Courier to engage a Sub-Contractor for the carriage of any of the goods subject to this contract at its discretion.</span></li>
            <li><span style="color: #858585; font-weight: 500;">3.2 The Sub-Contractor is deemed to be entitled to the full benefit of these terms and conditions to the same extent as the Courier. The Courier is deemed to have entered into this contract for its own benefit and also as agent for the Sub-Contractor.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>4. </span></div>
        <h3 style="color:#0ba6dd;">METHOD OF CARRIAGE.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">4.1 If the Customer instructs the Courier to use a particular method of carriage, whether by motorcycle, pickup, van, lorry, etc., the Courier will give priority to this method, provided that the method can reasonably and conveniently be adopted by the Courier. Where the Courier cannot reasonably and conveniently give priority to the method specified, the Courier may use any other method or methods to transport the goods at its absolute discretion, and the Customer is deemed to authorise such other method or methods.</span></li>
            <li><span style="color: #858585; font-weight: 500;">4.2The Customer is also deemed to have authorised all further or additional charges which may become payable as a result of the goods being carried by some other method or methods outlined in Clause 4.1.</span></li>
        </ul>
    </div>

    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>5. </span></div>
        <h3 style="color:#0ba6dd;">DELIVERY OF GOODS.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">5.1 The Courier is authorised to deliver the goods at the address given to the Courier by the Customer for that purpose, and without prejudice to any other method of delivery.</span></li>
            <li><span style="color: #858585; font-weight: 500;">5.2 The Courier is taken to deliver the goods specified in the Contract in accordance with the terms and conditions of the Contract if at that address the courier obtains from any person a receipt or signed delivery document for the goods.</span></li>
            <li><span style="color: #858585; font-weight: 500;">5.3 If the specified place of delivery is unattended or if the Courier is otherwise unable to effect the delivery, the Courier has the option to deposit the goods at that place or to store the goods. If the Courier decides to store the goods the Customer must pay or indemnify the Courier for all costs and expenses incurred in or about such storage. Furthermore, the Courier has the discretion to re- deliver the goods to the Customer from the place of storage at the Customer’s expense.</span></li>
            <li><span style="color: #858585; font-weight: 500;">5.4 If the Courier decides to deposit the goods in accordance with Clause 5.3, this is deemed to be delivery of the goods under this contract.</span></li>
            <li><span style="color: #858585; font-weight: 500;">5.5 Where a Courier accepts goods from a Customer for forwarding by road, an address in a town or other place where the Courier has no receiving depot, the goods are deemed to be properly delivered under this contract if they are delivered to the designated agent in that town or other place.</span></li>
            <li><span style="color: #858585; font-weight: 500;">5.6 The Customer agrees to any deviation by the Courier from the usual route or manner of carriage of the goods, which may be deemed by the Courier to be reasonable or necessary in the circumstances at its absolute discretion.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>6. </span></div>
        <h3 style="color:#0ba6dd;">RESPONSIBILITY FOR LOSS OR DAMAGE TO GOODS OR MISSED DELIVERY.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">6.1 Unless otherwise agreed in writing, the goods are earned at the risk of the Customer and the
Courier accepts no responsibility in tort or contract or otherwise for any loss or destruction of, or
damage to, or missed delivery or failure to deliver, or delay in delivery of goods either in transit or in
storage, whatever the reason.</span></li>
            <li><span style="color: #858585; font-weight: 500;">6.2 The Customer agrees to indemnify the Courier against all loss, damage and expense sustained
by any person (including the Courier) by reason of any such loss, damage, missed delivery, non-
delivery or delay in delivery as mentioned in Clause 6.1.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>7. </span></div>
        <h3 style="color:#0ba6dd;">EXPLOSIVE, INFLAMMABLE OR OTHERWISE DANGEROUS GOODS</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">7.1 The Customer or the Customer’s authorised agent must not tender any explosive,
inflammable, or otherwise dangerous or damaging goods for carriage by the Courier unless the
Customer gives the Courier a full description of the goods.</span></li>
            <li><span style="color: #858585; font-weight: 500;">7.2 If the Customer fails to comply with Clause 7.1, the Customer is liable for all loss and damage
resulting from this breach.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>8. </span></div>
        <h3 style="color:#0ba6dd;">CLAIMING FOR LOSS OR DAMAGE.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">8.1 Any claim by the Customer or the Consignee for loss or damage in whole or in part to the
goods the subject of this Contract which are the subject of insurance under clause 11 must be
lodged with the Courier in writing within seven (7) days from the date of dispatch of the goods.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>9. </span></div>
        <h3 style="color:#0ba6dd;">CUSTOMER’S WARRANTY AS TO OWNERSHIP OR OTHERWISE.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">9.1 The Customer expressly warrants to the Courier that the Customer is either the owner of, or
authorised agent of the owner, of any goods under this contract.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">9.2 By entering into this contract, the Customer agrees to accept these Terms and Conditions of
the contract of carriage on behalf of the Consignee, as well as for all other persons on whose behalf
the Customer is signing.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">9.3 The Customer agrees to indemnify the Courier for any liability whatsoever to any person in
respect of the goods subject to this Contract who claims to have, who has, or may have later on, any
interest in the goods in whole or in part.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>10. </span></div>
        <h3 style="color:#0ba6dd;">CUSTOMER’S WARRANTY AS TO PACKAGING OF GOODS.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">10.1 The Customer warrants that the Customer has complied with all laws and regulations relating
to nature, packaging, labelling or carriage of the goods and that the goods are packed in an
adequate manner to withstand the ordinary risks of carriage when having regard to the nature of
the goods.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">10.2 The Customer agrees to indemnify the Courier to the extent that the Customer fails to
comply with this warranty and loss or damage result from the Customer’s failure to comply.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>11. </span></div>
        <h3 style="color:#0ba6dd;">INSURANCE OF GOODS.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">11.1 The Courier will provide the insurance of goods as the agent of the Customer if the Customer
instructs the Courier to do so.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">11.2 To avoid doubt, it is not the responsibility of the Courier to effect insurance of goods.
Insurance of goods will only be provided by the Courier for the benefit of the Customer if the Courier
receives written instructions from the Customer and the Customer agrees to pay the cost of
insurance.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>12. </span></div>
        <h3 style="color:#0ba6dd;">CHARGES BY THE COURIER.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">12.1 The Courier’s charges are deemed to be earned as soon as the goods are loaded and
dispatched by the Courier.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">12.2 The Customer will be and remains responsible to the Courier for all proper charges incurred
by the Courier for any reason whatsoever.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>13. </span></div>
        <h3 style="color:#0ba6dd;">TERMS OF PAYMENT.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">13.1 The Customer agrees to pay by means of cash (CoD), PayPal, bank account transfer or mobile
money transfer upon receipt of the invoice. This is if the goods are meant to be paid for from the
location in which the goods are meant to be received from. The transaction charges, transport
charges and weight charges apply.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">13.2 The customer pays upon delivery if the goods are just to be collected and dropped. The
Customer can pay using the terms outlined under clause 13.1 above.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">13.3 (a) If any person fails to pay the charges due to the Courier for any service rendered by the
Courier upon reasonable demand being made under this contract, the Courier has the right to
detain and sell all or any other goods of that person which are in its possession.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(b) The Courier may also deduct charges so payable and all reasonable charges and expenses
resulting from the detention and sale of goods out of monies arising from the sale.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(c) If there is any surplus arising from the sale of the goods, the Courier must render the surplus to
the customer.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">13.4 Any sale under Clause 13.2 will not prejudice or otherwise affect the Courier’s right to
recover charges due or payable for services rendered or the detention or sales of goods from the
person liable to pay the charges.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">13.5 The Customer agrees to pay all costs, legal or otherwise, incurred in the collection of charges
due and owing by the Customer to the Courier for carriage of goods.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>14. </span></div>
        <h3 style="color:#0ba6dd;">CHARGES BY THE COURIER.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">14.1 The Customer shall not either by itself, or through any related person or corporation, engage one or more of the Courier’s employees, contractors or sub-contractors to perform the same or substantially the same or similar services or a part of those services previously performed for the Customer by or on behalf of the Courier within a 6 month period prior to the Customer’s engagement of such person or persons.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">14.2 If the Customer breaches the provisions of clause 14.1, the Customer will immediately pay to the Courier liquidated damages in the amount equivalent to the fees charged by the Courier to the Customer in the 12 month period to the date on which the Courier’s employee, contractor or sub- contractor, as the case may be, was so engaged, or if the Courier’s services have been provided to the Customer for a period of less than 12 months, then the amount equivalent to 12 times the average monthly fees charged by the Courier to the Customer.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>15. </span></div>
        <h3 style="color:#0ba6dd;">CHARGES BY THE COURIER.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">15.1 The Customer accepts that all rights, immunities and limitations of liability accruing to the
Courier under these Terms and Conditions continue to have full force and effect, notwithstanding
any breach of contract or any condition by the Courier.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">15.2 Notwithstanding anything in these Terms and Conditions, the Courier continues to be subject
to any implied warranty provided by the Trade Practices Act.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">15.3 The Courier is not bound by any agreement which purports to vary these Terms and
Conditions unless the agreement is in writing and signed by or on behalf of the Courier by its duly
authorised officer.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">15.4 These Terms and Conditions are to be governed and construed by the laws of the State in
which the Courier has its principal place of business wherever the contract is made. Accordingly, any
proceedings in respect of any claim, matter or thing against the Courier must be instituted in that
State only.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">15.5 The clauses and provisions in these Terms and Conditions are severable from each other and
if for any reason any clause or provision is invalid or unenforceable, such invalidity or
unenforceability does not prejudice or in any way affect the invalidity or unenforceability of any
other clause or provision of these Terms and Conditions.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>16. </span></div>
        <h3 style="color:#0ba6dd;">COMPENSATION FOR DAMAGE OR LOSS OF PARCEL/DOCUMENT.</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">16.1 For the Customer to be compensated they must do the following:</span></li>
            <small>1. When placing a request for delivery of an item, they must indicate the nature of the parcel, the
value of the parcel being transported. This way they know the correct amount of insurance they will
have to pay</small> <br> <br>
            <small>3. The must ensure that the parcel they want to send is not under the restricted or prohibited items.</small> <br>
            <small>4. They must ensure that they paid for compensation cover.</small> <br>
            <small>5. Prove the loss. This can be a letter from the intended recipient confirming that the item was
never delivered.</small> <br>
            <small>6. Prove the value. This can be by receipt/invoice. The receipt and invoice must contain business name, valid tax PIN of the business, Bank receipt that states the reason for payment.</small> <br>
            <small>7. Photographs of damage. The photographs must also show the item and where the damage has been sustained.</small> <br>
            <small>8. Photographs of the packaging. The photograph must also show the packaging that was used to protect the items of the Customer during the delivery, including the area where the damage occurred. The Customer must keep the packaging until the claim is resolved by the Courier as they will ask to see it during the investigation.</small> <br>
            <small style="width: 100%;">9. The Customer made the claim 1 day from the date of dispatch.</small> <br>
            <small style="width: 100%;width: 100%;color: rgb(35, 28, 28);font-weight: 700;font-size: 20px;padding: 10px;">It the above information is missing the claim may be rejected.</small> <br>
            <!-- <li><span style="color: #858585; font-weight: 500;list-style-type: none;">It the above information is missing the claim may be rejected.</span></li> -->
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">16.2 The compensation cover is 10% of the value of the parcel but the compensation cap is at a maximum of KES 5,000. The maximum cost of compensation cover is KES 500.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">16.3 Once the information is received the Courier will investigate the claim. Due to timescales of
the courier, the typical response time is 6 weeks. However, in some situations the time frame is
much longer. Once the claim is resolved the Courier will advise the Customer via email. Please note
that The Courier WILL NOT compensate the claimant on any losses incurred because of damage or
loss of the parcel or document, The Courier will only compensate on damage and loss of the parcel
or document if the item is legible for compensation.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">16.5 The Customer can appeal the decision on the claim if they do not agree with the decision of
the Courier. The Customer will have to contact the Courier via email and attach evidence on the
same.</span></li>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">16.6 The Courier does not offer compensation on restricted and prohibited items in Clauses 17.1
and 17.2.</span></li>
        </ul>
    </div>

    <!-- Definitions -->
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>1. </span></div>
        <h3 style="color:#0ba6dd;">Definitions</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">In these Conditions the following expressions shall have the meanings hereby respectively assignedto them, that is to say:</span></li>
            <p>a) “Client” shall mean the Customer who contracts the services of the Carrier.</p> <br>
            <p>b) “Consignment” shall mean goods in bulk or contained in one parcel or package, as the case may be, or any number of separate parcels or packages sent at one time in one load by or for the Client from one address to one address.</p> <br>
            <p>c) “Dangerous Goods” shall mean:</p> <br>
            <small>(i) goods, which are specified in special classification of dangerous goods issued by Communications Authority of Kenya or which, although not specified therein,</small> <br>
            <small>(ii) goods which although not indicated in (i) above are of a kindred nature.</small> <br><br>
            <p>d) “Contract” shall mean the contract of carriage between the Client and the Carrier.</p> <br>
            <br>
            <p>e) “Subcontracting parties” include all persons (other than the Carrier and the Client) referred to in Clause 3(3)</p>
            <p>f) “Carrier” save in the expression of Carrier/Contractor includes subcontracting parties in Clauses 4(2), 5(2) and (3) and 11 (proviso).</p>
            <p>g) “Carrier/Contractor” means the Carrier and any other carrier within Clause 3(2).</p>
            <p>h) “The excepted risks” means the absence, failure or inadequacy of packing and packaging</p>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>2. </span></div>
        <h3 style="color:#0ba6dd;">Carrier is not a Common Carrier</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">The Carrier is not a common carrier and will accept goods for carriage only on these conditions.</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>3. </span></div>
        <h3 style="color:#0ba6dd;">Parties and Subcontract</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(1) Where the Client is not the owner of some or all of the goods in any consignment, he shall be deemed for all purposes to be the agent of the owner or owners.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(2) The Carrier enters into the Contract for and on behalf of himself and servants, agents and subcontractors and his subcontractors’ servants, agents and subcontractors, all of whom shall be entitled to the benefit of the Contract and shall be under no liability whatsoever to the Client oranyone claiming through him in respect of the goods in addition to or separate from that of the Carrier under the Contract.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(3) The Client shall save harmless and keep the Carrier indemnified against all claims and demand whatsoever by whomsoever made in excess of the liability of the Carrier under these Conditions in respect of any loss, damage or injury, except if caused by the negligence of the Carrier, his servants, agents or subcontractors.</span></li> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>4. </span></div>
        <h3 style="color:#0ba6dd;">Dangerous Goods</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(1) The Carrier does not agrees to accept dangerous goods for carriage,</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(2) 2a. The client shall indemnify the    Carrier against all loss, damage or injury, however caused arising out of any dangerous goods whether declared as such or not.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">2b. Acceptable condition of goods All goods must be suitably and safely packaged. The carrier accepts no liability for any damage howsoever caused in the event of this condition not being complied with.</span></li> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>5. </span></div>
        <h3 style="color:#0ba6dd;">Loading or Unloading</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(1) When collection or delivery takes place at the Client’s premises, the Carrier/Contractor shall not be under any obligations to provide any plant, power or labour which, in additions to the Carrier/Contractor’s driver or dispatch rider, is required for loading or unloading at such premises.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(2) Any assistance given by the Carrier beyond the usual place of collection or delivery shall be at the sole risk of the Client who will save harmless and keep the Carrier indemnified against any claim or demand, which could not have been made if such assistance had not been given.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(3) Goods requiring special appliances for unloading from the vehicle are accepted only on condition that the sender had duly ascertained from the consignee that such appliances are available at the destination, Where the Carrier/Contractor is without prior arrangement in writing with the Client, called upon to load or unload such goods, the Carrier shall be under no liability whatsoever to the Client for any damage however caused, whether or not by the negligence of the Carrier and the Client shall save harmless and keep the Carrier indemnified against any claim or demand which could not have been made if such assistance had not been given.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(4) The Carrier will allow up to 15 minutes for waiting when picking up or delivering a consignment. Thereafter, the Carrier will charge the Client for the total waiting time (including the first 15 minutes) at the operative rate. If the Carrier has to leave the collection premises and re-attend because the items for collection are not available or cannot be collected because of their size or contents then the charge for the booking is payable in full. Subsequent visits are chargeable in addition to the initial visit.</span></li> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>6. </span></div>
        <h3 style="color:#0ba6dd;">Consignment Notes</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">The Carrier/Contractor shall, if so required, sign a document prepared by the sender acknowledging    the receipt of the consignment, but no such document shall be evidence of the condition of thecorrectness of the declared nature, quantity or weight of the consignment at the time it is received  by the Carrier/Contractor.</span></li> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>7. </span></div>
        <h3 style="color:#0ba6dd;">Proof of Delivery and Undeliverable consignments</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Where the Carrier/Contractor is unable for whatsoever reason to deliver a consignment to the  consignee he will take all reasonable steps to advise the client and obtain revised delivery    instructions. The carrier will always seek to obtain a signature or other proof of delivery. In the absence of specific instructions to the contrary by the Client the Carrier will not leave consignments  where they cannot obtain proof of delivery. Consignments may be returned to the Carriers premises   if the Client cannot be contacted to obtain the necessary permission. Increased delivery charges may be incurred in this way and the consignment will be delayed.</span></li> <br>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>8. </span></div>
        <h3 style="color:#0ba6dd;">The Limit for Claims</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(1) (i) for loss from a package or from an unpacked consignment: or</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(ii) for damage, deviation, missed delivery, delay of detention, unless the client is advised thereof in writing (otherwise than on a consignment note or delivery document) within fourteen days and the claim be made in writing within 21 days of the commencement of pick up. 21 days of the problem having occurred giving full description of the incident including cost, the carrier, will not accept liability. Please refer to clause 9 “Limitation of Liability”</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>9. </span></div>
        <h3 style="color:#0ba6dd;">Liability for Loss and Damage</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">Liability for Loss and Damage Subject to these Conditions the Carrier shall be liable for any loss, or missed delivery of or damage to goods occasioned during transit unless the Carrier shall prove that such loss, missed delivery or damage has arisen from</span></li> <br>
            <p>(i) Act of God;</p>
            <p>(ii) any consequence of war, invasion, act of foreign enemy, hostilities (whether war be declared or not), civil war, rebellion, insurrection, military or usurped power of confiscation, requisition, destruction of, or damage to property by or under the order of any government or public or local authority;</p>
            <p>(iii) seizure under legal process;</p>
            <p>(iv) act or emission of the Client or owner of the goods or of the servants or agents of either;</p>
            <p>(v) inherent liability to wastage in bulk or weight, latent defect or inherent defect vice or natural deterioration of the goods;</p>
            <p>(vi) insufficient or improper packaging;</p>
            <p>(vii) insufficient or improper labelling or addressing;</p>
            <p>(viii) riots, civil commotion, lockouts, general or partial stoppage or restraint of labour from whatever cause;</p>
            <p>(ix) consignee not taking or accepting delivery within a reasonable time. The Carrier shall not incur liability of any kind in respect of a consignment where there has been fraud on the part of the Client or the owner of the goods or the servants or agent of either in respect of that consignment.</p>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>10. </span></div>
        <h3 style="color:#0ba6dd;">Claim or Counterclaim</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">If you claim or counter claim against us it will not be the reason for deferring (putting off), or withholding payment or for refusing to repay any monies due under our credit terms.</span></li> <br>
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">(ii) for damage, deviation, missed delivery, delay of detention, unless the client is advised thereof in writing (otherwise than on a consignment note or delivery document) within fourteen days and the claim be made in writing within 21 days of the commencement of pick up. 21 days of the problem having occurred giving full description of the incident including cost, the carrier, will not accept liability. Please refer to clause 9 “Limitation of Liability”</span></li>
        </ul>
    </div>
    <VDivider />
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>11. </span></div>
        <h3 style="color:#0ba6dd;">Restrictions</h3>
        <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
        <ul style="font-weight: 600;color: #0ba6dd;list-style-type: circle;font-size: 20px;">
            <li><span style="color: #858585; font-weight: 500;list-style-type: none;">You may not:</span></li> <br>
            <p>(i) remove any copyright, trademark or other proprietary notices from any portion of the Services;</p>
            <p>(ii) reproduce, modify, prepare derivative works based upon, distribute, license, lease, sell, resell, transfer, publicly display, publicly perform, transmit, stream, broadcast or otherwise exploit the Services except as expressly permitted by Boxleo Courier & Fulfillment Services;</p>
            <p>(iii) decompile, reverse engineer or disassemble the Services except as may be permitted by applicable law;</p>
            <p>(iv) link to, mirror or frame any portion of the Services;</p>
            <p>(v) cause or launch any programs or scripts for the purpose of scraping, indexing, surveying, or otherwise data mining any portion of the Services or unduly burdening or hindering the operation</p>
        </ul>
    </div>

    <VDivider />
    <div class="icon-list">
        <p>Whilst BOXLEO COURIER & FULFILLMENT SERVICES does in fact take reasonable care in creating the information on this website, this website and its contents may contain errors, faults and inaccuracies, and may not be complete or current.</p><br>
        <p>Accordingly, use of this website is entirely at your own risk, and we make no representation or warranty of any kind, express or implied, as to the operation of this website, or as to the information, content, materials, suppliers or products included on this website.</p><br>
        <p>To the extent that this website might contain links to websites operated by third parties, we have not endorsed or approved such other websites, or the information and materials on those websites.</p><br>
        <p>Subject only to any responsibility or liability implied by law which cannot be excluded, we are not liable to you for any losses, damages, liabilities, claims and expenses whatsoever relating to or arising out of information, materials or services provided on or through our website, and where any responsibility or liability cannot by law be excluded, our liability is limited, to the extent possible, to the supply of the goods or services again, the repair of goods, or the payment of the costs of having the goods or services repaired or supplied again.</p><br>
        <p>Neither Boxleo Courier & Fulfillment Services nor the registered proprietor of Boxleo Courier & Fulfillment Services , nor any of their respective affiliates, directors, officers, employees, agents, contractors, successors or assigns shall be liable for any loss or damage whatsoever arising out of, or in any way related to, the use of or reliance upon this website, and any other website linked to thiswebsite, including any direct, indirect, consequential, special, punitive or other damages that you or others might suffer, including but not limited to damages for loss of profits, business interruption or the loss of data or information.</p><br>
        <p>Furthermore, we cannot guarantee that any file or program available for download from or via our website or from any website linked to our website is free from virus or any other condition which might or could damage or interfere with data, hardware or software with which it might be used, and in accessing this website, you assume all risk of use of all programs and files on this website, and you release Boxleo Courier & Fulfillment Services and the registered proprietors ofBoxleo Courier & Fulfillment Services and their respective affiliates, directors, officers, employees, agents, contractors, successors and assigns entirely from all responsibility or liability for any consequences of or arising out of your use of this website or any website linked to this website.</p>
    </div>
</div>
</template>

<style scoped>
ul li {
    list-style: none;
    padding: 5px 0;
}

ul small {
    color: #3333339c;
    float: left;
    margin-left: 40px;
}

.icon-list .icon-list-number {
    margin-top: -20px;
}

.icon-list p,
.page-content .icon-list p {
    color: #3333339c;
}
</style>
