<template>
<div>
    <!-- <p>What kinds of personal information does Boxleo Courier & Fulfillment Services collect and hold?</p> -->

    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>1. </span></div>
        <h3 style="color:#0ba6dd;">What kinds of personal information does Boxleo Courier & Fulfillment Services collect and hold?</h3>
        <p style="color:#a3a3a3;">
            The personal information we will collect from you depends on your relationship with Boxleo
            Courier & Fulfillment Services. As a customer or supplier it will generally include your
            name, business and email addresses and contact numbers, and may include your bank account
            details. If you are a franchisee of Boxleo Courier & Fulfillment Services personal information
            collected may extend beyond this to include your driver’s license number, vehicle registration
            number, financial details, photo and date of birth. We do not collect personal information that
            we do not need. Our website does not use persistent cookies.
        </p>
    </div>
    <v-divider></v-divider>
    <div class="vc_empty_space" style="height: 59px"><span class="vc_empty_space_inner"></span></div>
    <div class="icon-list">
        <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>2.</span></div>
        <h3 style="color:#0ba6dd;">How is personal information collected and held?</h3>
        <p style="color:#a3a3a3;">Boxleo Courier & Fulfillment Services collects most personal information directly from you.
            For example, when you become a customer, supplier or a franchisee you provide us with
            your information by filling in a form, dealing with us over the telephone, email or face to
            face, by sending us a letter, or by using our website. This information is held in hard copy
            and/or electronic databases. We may also collect information about you that is publicly
            available such as from other websites.</p>
    </div>
    <v-divider></v-divider>
    <div class="vc_empty_space" style="height: 35px"><span class="vc_empty_space_inner"></span></div>
    <div class="vc_tta-container" data-vc-action="collapse">
        <div class="vc_general vc_tta vc_tta-accordion vc_tta-color-white vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-no-fill clearfix faq-accordion">
            <div class="vc_tta-panels-container">
                <div class="vc_tta-panels">
                    <div class="vc_tta-panel" id="1458664012912-2ddbd332-3cd8" data-vc-content=".vc_tta-panel-body">
                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;margin-top: 40px;"><span>3.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">For what purpose does Boxleo Courier & Fulfillment Services collect, hold, use and disclose personal information?</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>
                                        We need to collect personal information to help us provide our products and services and
                                        conduct our business. Specifically, we need to collect personal information to interact with
                                        our drivers, customers, suppliers and franchisees and often to meet contractual obligations to
                                        these parties. Boxleo Courier & Fulfillment Services does not sell, rent or trade your personal
                                        information to third parties. However, your personal information may be disclosed to third
                                        parties if required by applicable laws, or to service providers who provide services in
                                        connection with our products and services. If you would like to opt out of receiving future
                                        communication from Boxleo Courier & Fulfillment Services you can do so by visiting or
                                        contacting our offices using the contact details set out on our online platforms, or by
                                        following instructions on the communication to opt out
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_tta-panel" id="1458664416829-7adc69fc-eff6" data-vc-content=".vc_tta-panel-body">

                        <div class="icon-list">
                            <div class="icon-list-number" style="border-color:#0ba6dd;color:#0ba6dd;"><span>4.</span></div>
                            <h4 class="vc_tta-panel-title vc_tta-controls-icon-position-right"><a href="#" data-vc-accordion="" data-vc-container=".vc_tta-container"><span class="vc_tta-title-text" style="color:#0ba6dd;">Security</span><i class="vc_tta-controls-icon vc_tta-controls-icon-triangle"></i></a></h4>
                        </div>
                        <div class="vc_tta-panel-body" style="">
                            <div class="wpb_text_column wpb_content_element vc_custom_1458664357726">
                                <div class="wpb_wrapper">
                                    <p>Boxleo Courier & Fulfillment Services takes reasonable steps to ensure the security of your
                                        personal information. We frequently update our anti-virus software to protect our systems
                                        from computer viruses. In addition to that, all Boxleo Courier & Fulfillment Services
                                        employees are required, as a condition of employment, to treat personal information held by
                                        Boxleo Courier & Fulfillment Services as confidential. However, you should be aware that
                                        the internet is not a secure environment. We cannot protect personal information before it
                                        reaches us.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</template>
