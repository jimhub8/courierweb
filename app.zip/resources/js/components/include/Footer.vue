<template>
<div>
    <v-divider></v-divider>
    <v-layout wrap style="align-items: center;margin-top: 30px;" class="container">
        <v-flex sm4 style="margin-top: -30px;">
            <h3>WORKING HOURS</h3>
            <v-layout wrap>
                <v-flex sm2>
                    <v-btn icon :color="icon_back">
                        <v-icon :color="color">alarm</v-icon>
                    </v-btn>
                </v-flex>
                <v-flex sm10>
                    <span><strong>Weekday Working Hours:</strong> 09:00 - 17:00</span><br>
                    <span><strong>Saturday Working Hours:</strong> 10:00 - 13:00</span>
                </v-flex>
            </v-layout>
        </v-flex>
        <v-flex sm4>
            <h3>ADDRESS INFORMATIONS</h3>
            <v-layout wrap>
                <v-flex sm2>
                    <v-btn icon :color="icon_back">
                        <v-icon :color="color">edit_location</v-icon>
                    </v-btn>
                </v-flex>
                <v-flex sm10>
                    <address><strong>Head Office:</strong> 8149 Myrtle Avenue, MA 018</address>
                    <address><strong>NC Office:</strong> 3534 East Avenue Cary</address>
                </v-flex>
            </v-layout>
        </v-flex>
        <v-flex sm4 style="margin-top: -40px;">
            <h3>ADDRESS INFORMATIONS</h3>
            <v-layout wrap>
                <v-flex sm12>
                    <form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-237" method="post" data-id="237" data-name="Translogistic Footer Newsletter">
                        <div class="mc4wp-form-fields">
                            <div class="footer-newsletter">
                                <v-btn icon :color="icon_back">
                                    <v-icon :color="color" style="margin-right: 0; margin-top: 0;">email</v-icon>
                                </v-btn>
                                <input type="submit" value="SUBSCRIBE"> <input type="email" name="EMAIL" placeholder="Your Email" required="">
                            </div>
                            </div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off"></label><input type="hidden" name="_mc4wp_timestamp" value="1556181772"><input type="hidden" name="_mc4wp_form_id" value="237"><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1">
                            <div class="mc4wp-response"></div>
                    </form>
                </v-flex>
            </v-layout>
        </v-flex>
    </v-layout>
    <v-divider></v-divider>

    <v-layout wrap style="align-items: center;" class="container">
        <v-flex sm2>
            <img src="/storage/img/client1.jpg" alt="">
                    </v-flex>
            <v-flex sm2>
                <img src="/storage/img/client2.jpg" alt="">
                    </v-flex>
                <v-flex sm2>
                    <img src="/storage/img/client3.jpg" alt="">
                    </v-flex>
                    <v-flex sm2>
                        <img src="/storage/img/client4.jpg" alt="">
                    </v-flex>
                        <v-flex sm2>
                            <img src="/storage/img/client5.jpg" alt="">
                    </v-flex>
                            <v-flex sm2>
                                <img src="/storage/img/client6.jpg" alt="">
                    </v-flex>
    </v-layout>
    <v-divider></v-divider>
    <div style="align-items: center;background: rgb(0, 118, 192);height: 400px;">

        <v-layout wrap class="container">
            <v-flex sm3>
                <h3>ABOUT US</h3>
                <p style="color: #fff;">Phasellus vitae fermentum diam, in gravida mi. Vestibulum efficitur ipsum maximus purus ultricies lacinia. Aliquam ullamcorper nec nulla ut eleifend.

                    Quisque nisl augue, accumsan ut blandit et, pulvinar nec mauris. Etiam sagittis euismod dolor, sed accumsan tellus maximus non.Phasellus vitae fermentum diam.</p>
            </v-flex>
            <v-flex sm3>
                <h3>LOGISTIC PROCESS</h3>
                <ul id="menu-logistic-process" class="menu">
                    <li id="menu-item-266" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-266"><a href="#">Expertise Services</a></li>
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="#">Packaging</a></li>
                    <li id="menu-item-268" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-268"><a href="#">Transportation</a></li>
                    <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="#">Delivery</a></li>
                </ul>
            </v-flex>
            <v-flex sm3>
                <h3>SERVICES</h3>
                <ul id="menu-services" class="menu">
                    <li id="menu-item-274" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-274"><a href="#">Airline</a></li>
                    <li id="menu-item-275" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-275"><a href="#">Event</a></li>
                    <li id="menu-item-276" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-276"><a href="#">Land</a></li>
                    <li id="menu-item-277" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-277"><a href="#">Maritime</a></li>
                    <li id="menu-item-278" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-278"><a href="#">Railway</a></li>
                </ul>
            </v-flex>
            <v-flex sm3>
                <h3>NEW CARGO QUERY</h3>
                <p style="color: #fff;">Phasellus vitae fermentum diam, in gravida mi. Vestibulum efficitur ipsum maximus purus ultricies lacinia. Aliquam ullamcorper nec nulla ut eleifend.

                    Quisque nisl augue, accumsan ut blandit et, pulvinar nec mauris. Etiam sagittis euismod dolor, sed accumsan tellus maximus non.Phasellus vitae fermentum diam.</p>

                <div class="cargo-tracking-form white">
                    <form action="http://demo.gloriathemes.com/wp/translogistic/cargo-tracking/" method="post" enctype="multipart/form-data">
                        <div class="input-group" style="background: rgb(0, 118, 192)">
                            <span class="input-group-addon">
                            <i class="fa fa-info-circle"></i></span>
                            <input type="text" name="cargo_tracking_code_text" placeholder="Cargo Tracking Number" style="background: rgb(0, 118, 192)">
                            <input type="submit" value="Track" style="background: rgb(0, 118, 192)">
                        </div>
                    </form>
                </div>
            </v-flex>
        </v-layout>
    </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      icon_back: "#fff",
      color: "#0ba6dd"
    };
  }
};
</script>

<style scoped>
.form-group input[type="email"] {
  float: right;
  max-width: 209px;
  border-top-left-radius: 25px;
  border-bottom-left-radius: 25px;
  padding: 11px 20px;
  font-family: "Roboto";
  letter-spacing: 0.25px;
  height: 39px;
}

.sm4 h3::before {
  content: "";
  display: inline-block;
  top: -1px;
  position: relative;
  width: 11px;
  height: 11px;
  border: 2px solid #b2b2b2;
  margin-right: 11px;
  margin-left: 3px;
  transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
}

.container .sm3 h3::before {
  content: "";
  display: inline-block;
  top: -1px;
  position: relative;
  width: 11px;
  height: 11px;
  border: 2px solid #fff;
  margin-right: 11px;
  margin-left: 3px;
  transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
}

.container .sm3 h3 {
  color: #fff;
}

.menu a {
  color: #fff;
}

.menu li {
  color: #fff;
  list-style-type: circle;
}
</style>
