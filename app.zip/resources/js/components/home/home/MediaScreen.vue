<template>
<div>
    <div class="row">
        <div class="col-sm-12 col-md-6">
            <div class="owl-item active col-md-12" style="text-align: center;">
                <div class="item alternative anim-fadeInLeft">
                    <div class="image">

                        <img src="/storage/web/zuri.jpg" alt="Customer"></div>
                    <div class="testimonial-modern-item-name">
                        <span class="name" style="color: rgb(0, 118, 192);">LILLY MACHARIA,</span>
                        <span class="company">ZURI KIDS</span>
                    </div>
                    <div class="testimonial-modern-item-content">
                        <p>Boxleo Courier & Fulfillment Services provides
                            us with a quality express courier services, with
                            products reaching our customers in plenty of
                            time, while offering great value for money. I would
                            recommend them to anyone.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-6">
            <div class="owl-item active col-md-12" style="text-align: center;">
                <div class="item alternative anim-fadeInRight">
                    <div class="image">
                        <img src="/storage/web/oloo.jpg" alt="Customer">
                    </div>
                        <div class="testimonial-modern-item-name">
                            <span class="name" style="color: rgb(0, 118, 192);">OLIVER WEKESA,</span>
                            <span class="company">OLOO COLLECTION</span>
                        </div>
                        <div class="testimonial-modern-item-content">
                            <p>Boxleo Courier & Fulfillment
                                Services has helped us save time
                                during key decision-making
                                processes and implement an
                                efficient package delivery service to
                                all our customers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
img {
    width: 130px;
    border-radius: 50%;
    height: 130px;
}
.alternative .testimonial-modern  {
    width: 60% !important;
    text-align: center;
}
</style>
