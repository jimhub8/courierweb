 
<?php $__env->startSection('content'); ?>
    <my-header :company="<?php echo e(json_encode($company)); ?>" :user="<?php echo e(json_encode($auth_user)); ?>"></my-header>
    <router-view :user="<?php echo e(json_encode($auth_user)); ?>"></router-view>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>