<?php $__env->startComponent('mail::message'); ?>
# Introduction





<?php $__env->startComponent('mail::panel'); ?>
Attached is your monthly shipment report
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
