<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="/storage/icons/favicon.png" />
    <!--===============================================================================================-->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">  
    <!--===============================================================================================-->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/elegant-font/html-css/style.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animsition/css/animsition.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/daterangepicker/daterangepicker.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/slick/slick.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/lightbox2/css/lightbox.min.css')); ?>">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main1.css')); ?>">
    <!--===============================================================================================-->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
</head>

<body class="animsition">
    <div id="app">
        
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
    </div>
    

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/animsition/js/animsition.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/popper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(".selection-1").select2({
        minimumResultsForSearch: 20,
        dropdownParent: $('#dropDownSelect1')
    });
    </script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/slick/slick.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/slick-custom.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/countdowntime/countdowntime.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/lightbox2/js/lightbox.min.js')); ?>"></script>
    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/sweetalert/sweetalert.min.js')); ?>"></script>
    <script type="text/javascript">
        $('.block2-btn-addcart').each(function(){
        var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
        $(this).on('click', function(){
            swal(nameProduct, "is added to cart !", "success");
        });
    });

    $('.block2-btn-addwishlist').each(function(){
        var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
        $(this).on('click', function(){
            swal(nameProduct, "is added to wishlist !", "success");
        });
    });
    </script>

    <!--===============================================================================================-->
    <script type="text/javascript" src="<?php echo e(asset('vendor/parallax100/parallax100.js')); ?>"></script>
    <script type="text/javascript">
        $('.parallax100').parallax100();
    </script>
    <!--===============================================================================================-->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>

</body>

</html>