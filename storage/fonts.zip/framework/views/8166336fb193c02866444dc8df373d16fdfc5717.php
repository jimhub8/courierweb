 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo e($product->name); ?></div>

                <div class="card-body">
                    <?php echo e($product->description); ?>

                </div>
                <div class="card-footer">
                    <form action="cart/<?php echo e($product->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary">Add to cart</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>