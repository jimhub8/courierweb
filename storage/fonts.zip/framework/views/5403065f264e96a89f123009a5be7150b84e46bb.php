 
<?php $__env->startSection('content'); ?> <?php if(auth()->guard()->check()): ?>
<my-nav :user="<?php echo e(json_encode($auth_user)); ?>"></my-nav>
<transition name="fade">
    <router-view :user="<?php echo e(json_encode($auth_user)); ?>"></router-view>
</transition>
<?php endif; ?> <?php if(auth()->guard()->guest()): ?>
<my-nav></my-nav>
<transition name="fade">
    <router-view></router-view>
</transition>

<?php endif; ?>
<my-footer></my-footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>